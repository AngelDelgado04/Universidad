-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-02-2022 a las 18:44:00
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `niñosanos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consultas`
--

CREATE TABLE `consultas` (
  `id_consulta` int(11) NOT NULL,
  `num_med` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `fecha_consulta` date NOT NULL,
  `peso` varchar(4) NOT NULL,
  `estatura` varchar(4) NOT NULL,
  `num_paciente` int(11) NOT NULL,
  `sueño_pac` int(11) NOT NULL,
  `examenf_pac` int(11) NOT NULL,
  `complicacion_pac` int(11) NOT NULL,
  `alimentacion_pac` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen`
--

CREATE TABLE `examen` (
  `id_examen` int(11) NOT NULL,
  `num_examen` int(11) NOT NULL,
  `nombre_examen` varchar(20) NOT NULL,
  `examen_disponible` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen_consulta`
--

CREATE TABLE `examen_consulta` (
  `id_ex` int(11) NOT NULL,
  `num_consulta` int(11) NOT NULL,
  `tipo_medicina` varchar(20) NOT NULL,
  `alergia_medicina` varchar(20) NOT NULL,
  `dosis` float NOT NULL,
  `tiempo_dosis` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicina`
--

CREATE TABLE `medicina` (
  `id_medicina` int(11) NOT NULL,
  `num_medicina` int(11) NOT NULL,
  `nombre_medicina` varchar(20) NOT NULL,
  `medicina_disponible` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicinacon`
--

CREATE TABLE `medicinacon` (
  `id_medicina` int(11) NOT NULL,
  `num_medicina` int(11) NOT NULL,
  `num_consulta` int(11) NOT NULL,
  `tipo_medicinas` varchar(20) NOT NULL,
  `alergia_medicina` varchar(20) NOT NULL,
  `dosis` float NOT NULL,
  `tiempo_dosis` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicos`
--

CREATE TABLE `medicos` (
  `id_medico` int(11) NOT NULL,
  `cedula_med` varchar(11) NOT NULL,
  `nombre_med` varchar(20) NOT NULL,
  `apellido_med` varchar(20) NOT NULL,
  `correo_med` varchar(50) NOT NULL,
  `horario_trabajo_doctor` varchar(20) NOT NULL,
  `fecha_ingreso_doctor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacientes`
--

CREATE TABLE `pacientes` (
  `id_paciente` int(11) NOT NULL,
  `cedula_paciente` varchar(12) NOT NULL,
  `nombre_pac` varchar(20) NOT NULL,
  `fechadenacimiento` date NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `peso_nacimiento_pac` varchar(4) NOT NULL,
  `estatura_nacimiento_pac` varchar(4) NOT NULL,
  `id_representante` int(11) NOT NULL,
  `antec_pers_no_patologicos` varchar(34) NOT NULL,
  `antec_prenatales_pac` varchar(34) NOT NULL,
  `antec_postnatales_pac` varchar(34) NOT NULL,
  `desarrollo_psicomotor_pac` varchar(34) NOT NULL,
  `antec_heredo_familiar` varchar(34) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacientesvac`
--

CREATE TABLE `pacientesvac` (
  `id_vacunap` int(11) NOT NULL,
  `fecha_vacunacion` date NOT NULL,
  `dosis_vacuna` varchar(20) NOT NULL,
  `id_paciente` varchar(11) NOT NULL,
  `id_vacuna` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representante`
--

CREATE TABLE `representante` (
  `id_representantes` int(11) NOT NULL,
  `cedula_representantes` varchar(12) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `telefono_representantes` varchar(12) NOT NULL,
  `antecedentes_personales` varchar(50) NOT NULL,
  `direccion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacunas`
--

CREATE TABLE `vacunas` (
  `id_vacunas` int(11) NOT NULL,
  `codigo_vacuna` int(11) NOT NULL,
  `nombre_vacuna` varchar(30) NOT NULL,
  `vacuna_disponible` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `consultas`
--
ALTER TABLE `consultas`
  ADD PRIMARY KEY (`id_consulta`);

--
-- Indices de la tabla `examen`
--
ALTER TABLE `examen`
  ADD PRIMARY KEY (`id_examen`);

--
-- Indices de la tabla `examen_consulta`
--
ALTER TABLE `examen_consulta`
  ADD PRIMARY KEY (`id_ex`);

--
-- Indices de la tabla `medicina`
--
ALTER TABLE `medicina`
  ADD PRIMARY KEY (`id_medicina`);

--
-- Indices de la tabla `medicinacon`
--
ALTER TABLE `medicinacon`
  ADD PRIMARY KEY (`id_medicina`);

--
-- Indices de la tabla `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`id_medico`),
  ADD UNIQUE KEY `cedula_med` (`cedula_med`);

--
-- Indices de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`id_paciente`),
  ADD UNIQUE KEY `cedula_paciente` (`cedula_paciente`),
  ADD KEY `id_representante` (`id_representante`);

--
-- Indices de la tabla `pacientesvac`
--
ALTER TABLE `pacientesvac`
  ADD PRIMARY KEY (`id_vacunap`),
  ADD KEY `id_paciente` (`id_paciente`),
  ADD KEY `pacientesvac_ibfk_1` (`id_vacuna`);

--
-- Indices de la tabla `representante`
--
ALTER TABLE `representante`
  ADD PRIMARY KEY (`id_representantes`),
  ADD UNIQUE KEY `cedula_representantes` (`cedula_representantes`);

--
-- Indices de la tabla `vacunas`
--
ALTER TABLE `vacunas`
  ADD PRIMARY KEY (`id_vacunas`),
  ADD UNIQUE KEY `codigo_vacuna` (`codigo_vacuna`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `consultas`
--
ALTER TABLE `consultas`
  MODIFY `id_consulta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `examen`
--
ALTER TABLE `examen`
  MODIFY `id_examen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `examen_consulta`
--
ALTER TABLE `examen_consulta`
  MODIFY `id_ex` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `medicina`
--
ALTER TABLE `medicina`
  MODIFY `id_medicina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `medicinacon`
--
ALTER TABLE `medicinacon`
  MODIFY `id_medicina` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `medicos`
--
ALTER TABLE `medicos`
  MODIFY `id_medico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `id_paciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pacientesvac`
--
ALTER TABLE `pacientesvac`
  MODIFY `id_vacunap` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `representante`
--
ALTER TABLE `representante`
  MODIFY `id_representantes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `vacunas`
--
ALTER TABLE `vacunas`
  MODIFY `id_vacunas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pacientes`
--
ALTER TABLE `pacientes`
  ADD CONSTRAINT `pacientes_ibfk_1` FOREIGN KEY (`id_representante`) REFERENCES `representante` (`id_representantes`);

--
-- Filtros para la tabla `pacientesvac`
--
ALTER TABLE `pacientesvac`
  ADD CONSTRAINT `pacientesvac_ibfk_1` FOREIGN KEY (`id_vacuna`) REFERENCES `vacunas` (`codigo_vacuna`),
  ADD CONSTRAINT `pacientesvac_ibfk_2` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`cedula_paciente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
