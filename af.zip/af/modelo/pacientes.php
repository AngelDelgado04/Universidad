<?php

require_once('modelo/datos.php');



class pacientes extends datos{

	private $cedula; //recuerden que en php, las variables no tienen tipo predefinido
	private $nombre;
	private $fechadenacimiento;
	private $pesonacimiento;
	private $sexo;
	private $estnacimiento;
	private $desarrollopsi;
	private $antecnopato;
	private $antecheredo;
	private $antecpre;
	private $antecpost;
	private $idrepresentante;
	
	
	//Ok ya tenemos los atributos, pero como son privados no podemos acceder a ellos desde fueran
	//por lo que debemos colcoar metodos (funciones) que me permitan leer (get) y colocar (set)
	//valores en ello, esto es  muy mal llamado geters y seters por si alguien se los pregunta
	
	function set_cedula($valor){
		$this->cedula = $valor; //fijencen como se accede a los elementos dentro de una clase
		//this que singnifica esto es decir esta clase luego -> simbolo que indica que apunte
		//a un elemento de this, es decir esta clase
		//luego el razon del elemento sin el $
	}
	//lo mismo que se hizo para cedula se hace para usuario y clave
	
	function set_nombre($valor){
		$this->nombre = $valor;
	}
	function set_fechadenacimiento($valor){
		$this->fechadenacimiento =  $valor;
	}
	function set_sexo($valor){
		$this->sexo = $valor;
	}
	function set_pesonacimiento($valor){
		$this->pesonacimiento = $valor;
	}
	function set_estnacimiento($valor){
		$this->estnacimiento = $valor;
	}
	function set_desarrollopsi($valor){
		$this->desarrollopsi = $valor;
	}
	function set_antecnopato($valor){
		$this->antecnopato = $valor;
	}
	function set_antecheredo($valor){
		$this->antecheredo = $valor;
	}
	function set_antecpre($valor){
		$this->antecpre = $valor;
	}
	function set_antecpost($valor){
		$this->antecpost = $valor;
	}
	function set_idrepresentante($valor){
		$this->idrepresentante = $valor;
	}
	
	
	//Lo siguiente que demos hacer es crear los metodos para incluir, consultar y eliminar
	
	function incluir(){
		//Ok ya tenemos la base de datos y la funcion conecta dentro de la clase
		//datos, ahora debemos ejecutar las operaciones para realizar las consultas 
		
		//Lo primero que debemos hacer es consultar por el campo clave
		//en este caso la cedula, para ello se creo la funcion existe
		//que retorna true en caso de exitir el registro
		
		if(!$this->existe($this->cedula)){
			//si estamos aca es porque la cedula no existe es decir se puede incluir
			//los pasos a seguir son
			//1 Se llama a la funcion conecta 
			
			$co = $this->conecta();
			$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//2 Se ejecuta el sql
			try {
					$r = $co->prepare("Insert into pacientes(
						id_representante,
						nombre_pac,
						cedula_paciente,
						fechadenacimiento,
						sexo,
						peso_nacimiento_pac,
						estatura_nacimiento_pac,
						desarrollo_psicomotor_pac,
						antec_pers_no_patologicos,
						antec_heredo_familiar,
						antec_prenatales_pac,
						antec_postnatales_pac
						)
						Values(
						:idrepresentante,
						:nombre,
						:cedula,	
	                    :fechadenacimiento,
	                    :sexo,
	                    :pesonacimiento,
	                    :estnacimiento,
	                    :desarrollopsi,
	                    :antecnopato,
	                    :antecheredo,
	                    :antecpre,
	                    :antecpost
						)");
					
					$r->bindParam(':idrepresentante',$this->idrepresentante);	
					$r->bindParam(':nombre',$this->nombre);
					$r->bindParam(':cedula',$this->cedula);	
					$r->bindParam(':fechadenacimiento',$this->fechadenacimiento);
					$r->bindParam(':sexo',$this->sexo);
					$r->bindParam(':pesonacimiento',$this->pesonacimiento);	
					$r->bindParam(':estnacimiento',$this->estnacimiento);
					$r->bindParam(':desarrollopsi',$this->desarrollopsi);
					$r->bindParam(':antecnopato',$this->antecnopato);
					$r->bindParam(':antecheredo',$this->antecheredo);
					$r->bindParam(':antecpre',$this->antecpre);
					$r->bindParam(':antecpost',$this->antecpost);		
					$r->execute();
					
						return "Registro incluido";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Ya existe la cedula que desea ingresar";
		}
		
		//Listo eso es todo y es igual para el resto de las operaciones
		//incluir, modificar y eliminar
		//solo cambia para buscar 
	}
	
	function modificar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->cedula)){
			try {
					$r = $co->prepare("Update pacientes set 
						id_representante = :idrepresentante,
					    nombre_pac = :nombre,
						fechadenacimiento = :fechadenacimiento,
						sexo = :sexo,
						peso_nacimiento_pac = :pesonacimiento,
						estatura_nacimiento_pac = :estnacimiento,
						desarrollo_psicomotor_pac = :desarrollopsi,
						antec_pers_no_patologicos = :antecnopato,
						antec_heredo_familiar = :antecheredo,
						antec_prenatales_pac = :antecpre,
						antec_postnatales_pac = :antecpost
						where
						cedula_paciente = :cedula
						");
					
					$r->bindParam(':idrepresentante',$this->idrepresentante);	
			        $r->bindParam(':nombre',$this->nombre);
					$r->bindParam(':cedula',$this->cedula);	
					$r->bindParam(':fechadenacimiento',$this->fechadenacimiento);	
					$r->bindParam(':sexo',$this->sexo);
					$r->bindParam(':pesonacimiento',$this->pesonacimiento);	
					$r->bindParam(':estnacimiento',$this->estnacimiento);
					$r->bindParam(':desarrollopsi',$this->desarrollopsi);
					$r->bindParam(':antecnopato',$this->antecnopato);
					$r->bindParam(':antecheredo',$this->antecheredo);
					$r->bindParam(':antecpre',$this->antecpre);
					$r->bindParam(':antecpost',$this->antecpost);
					
					$r->execute();
						
						
						
						return "Registro Modificado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Cedula no registrada";
		}
		
	}
	
	function eliminar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->cedula)){
			try {
					$r = $co->prepare("Delete from pacientes
						where
						cedula_paciente = :cedula
						");
					$r->bindParam(':cedula',$this->cedula);	
					
					$r->execute();
					
						return "Registro Eliminado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Cedula no registrada";
		}
	}
	
	
	function consultar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from pacientes");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='coloca(this);'>";
						$respuesta = $respuesta."<td style='display:none'>";
							$respuesta = $respuesta.$r['id_representante'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_paciente'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fechadenacimiento'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['sexo'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['peso_nacimiento_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['estatura_nacimiento_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['desarrollo_psicomotor_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_pers_no_patologicos'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_heredo_familiar'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_prenatales_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_postnatales_pac'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
	
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	private function existe($cedula){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			//AQUI COMENZAREMOS A HACER USO DE LO QUE SON LAS CONSULTAS PARAMETRIZABLES
			//PARA ELLO UTILIZAREMOS LA INSTRUCCIÓN Y AÑADIREMOS LOS PASOS PREPARE
			//Y EXECUTE PARA REGISTRAR O CONSULTAR EN LA BASE DE DATOS
			
			//ANTERIORMENTE ERA query(consuta sql)
			//$resultado = $co->query("Select * from paciente where cedula_paciente='$cedula'");
			
			//AHORA QUEDA
			$resultado = $co->prepare("Select * from pacientes where cedula_paciente=:cedula");
			//COMO VEN SE CAMBIO A $cedula QUE ES UNA VARIABLE QUE SE USA POR :cedula
			//QUE ES UN VALOR NO DECLARADO, POR LO QUE EL SIGUIETE PASO SERA 
			//INDICARLE A PHP QUIEN ES ESE :cedula Y PARA ELLO USAREMOS LA INSTRUCCION
			//bindParam QUE COLOCA UN VALOR EN :cedula Y EVITA QUE SE INCLUYAN 
			//INSTRUCCIONES QUE SE PUEDEN USAR EN MYSQL INJECT
			$resultado->bindParam(':cedula',$cedula);
			//YA SE TIENE EL VALOR DE :cedula
			//EL SIGUIENTE PASO ES EJUTAR LA CONSULTA
			
			$resultado->execute();
			
			//LO DEMAS QUEDA IGUAL
			$fila = $resultado->fetchAll(PDO::FETCH_BOTH);
			if($fila){

				return true;
			    
			}
			else{
				
				return false;;
			}
			
		}catch(Exception $e){
			return false;
		}
	}

   

	
	function listadoderepresentantes(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from representante");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='colocarepresentante(this);'>";
						$respuesta = $respuesta."<td style='display:none'>";
							$respuesta = $respuesta.$r['id_representantes'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_representantes'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['direccion'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['antecedentes_personales'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['correo'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['telefono_representantes'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	
	
}


?>