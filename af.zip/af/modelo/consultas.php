<?php

require_once('modelo/datos.php');



class consultas extends datos{

	private $feccon; //recuerden que en php, las variables no tienen tipo predefinido
	private $horincon;
	private $pesocon;
	private $estcon;
	private $hordorm;
	private $examenfis;
	private $comppac;
	private $observaciones;
	private $idrepresentante;
	private $idcliente;
	
	//Ok ya tenemos los atributos, pero como son privados no podemos acceder a ellos desde fueran
	//por lo que debemos colcoar metodos (funciones) que me permitan leer (get) y colocar (set)
	//valores en ello, esto es  muy mal llamado geters y seters por si alguien se los pregunta
	
	function set_feccon($valor){
		$this->feccon = $valor; //fijencen como se accede a los elementos dentro de una clase
		//this que singnifica esto es decir esta clase luego -> simbolo que indica que apunte
		//a un elemento de this, es decir esta clase
		//luego el razon del elemento sin el $
	}
	//lo mismo que se hizo para feccon se hace para usuario y clave
	
	function set_horincon($valor){
		$this->horincon = $valor;
	}
	function set_estcon($valor){
		$this->estcon = $valor;
	}
	function set_pesocon($valor){
		$this->pesocon = $valor;
	}
	function set_hordorm($valor){
		$this->hordorm = $valor;
	}
	function set_examenfis($valor){
		$this->examenfis = $valor;
	}
	function set_comppac($valor){
		$this->comppac = $valor;
	}
	function set_observaciones($valor){
		$this->observaciones = $valor;
	}
	function set_idrepresentante($valor){
		$this->idrepresentante = $valor;
	}	
	function set_idcliente($valor){
		$this->idcliente = $valor;
	}
	//Lo siguiente que demos hacer es crear los metodos para incluir, consultar y eliminar
	
	function incluir(){
		
		if(!$this->existe($this->feccon)){
			//si estamos aca es porque la feccon no existe es decir se puede incluir
			//los pasos a seguir son
			//1 Se llama a la funcion conecta 
			
			$co = $this->conecta();
			$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//2 Se ejecuta el sql
			try {
					$r = $co->prepare("INSERT INTO consultas(
					    num_med,
						id_pac,
						id_vacuna,
						hora_inicio,
						fecha_consulta,
						peso,
						estatura,
						sueño_pac,
						examenf_pac,
						complicacion_pac,
						observacion_pac
						)
						VALUES(
						:idrepresentante,
						:idcliente,
						:horincon,
						:feccon,	
	                    :estcon,
	                    :pesocon,
	                    :hordorm,
	                    :examenfis,
	                    :comppac,
	                    :observaciones
						)");
					
					$r->bindParam(':idrepresentante',$this->idrepresentante);
					$r->bindParam(':idcliente',$this->idcliente);
					$r->bindParam(':horincon',$this->horincon);
					$r->bindParam(':feccon',$this->feccon);	
					$r->bindParam(':estcon',$this->estcon);
					$r->bindParam(':pesocon',$this->pesocon);	
					$r->bindParam(':hordorm',$this->hordorm);
					$r->bindParam(':examenfis',$this->examenfis);
					$r->bindParam(':comppac',$this->comppac);	
					$r->bindParam(':observaciones',$this->observaciones);	
					$r->execute();
					
						return "Registro incluido";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Ya existe la feccon que desea ingresar";
		}
		
		//Listo eso es todo y es igual para el resto de las operaciones
		//incluir, modificar y eliminar
		//solo cambia para buscar 
	}
	
	function modificar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->feccon)){
			try {
					$r = $co->prepare("UPDATE consultas SET 
					    num_med = :idrepresentante,
						id_pac = :idcliente,
						hora_inicio = :horincon,
						estatura = :estcon,
						peso = :pesocon,
						sueño_pac = :hordorm,
						examenf_pac = :examenfis,
						complicacion_pac = :comppac,
						observacion_pac = :observaciones
						WHERE	
						fecha_consulta = :feccon
						");
					
					$r->bindParam(':idrepresentante',$this->idrepresentante);
					$r->bindParam(':idcliente',$this->idcliente);
					$r->bindParam(':feccon',$this->feccon);	
					$r->bindParam(':horincon',$this->horincon);	
					$r->bindParam(':estcon',$this->estcon);
					$r->bindParam(':pesocon',$this->pesocon);
					$r->bindParam(':hordorm',$this->hordorm);
					$r->bindParam(':examenfis',$this->examenfis);
					$r->bindParam(':comppac',$this->comppac);
					$r->bindParam(':observaciones',$this->observaciones);
					$r->execute();
						
						
						
						return "Registro Modificado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "feccon no registrada";
		}
		
	}
	
	function eliminar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->feccon)){
			try {
					$r = $co->prepare("DELETE FROM consultas
						WHERE
						fecha_consulta = :feccon
						");
					$r->bindParam(':feccon',$this->feccon);	
					
					$r->execute();
					
						return "Registro Eliminado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "feccon no registrada";
		}
	}
	
	
	function consultar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("SELECT * FROM consultas");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='coloca(this);'>";
					    $respuesta = $respuesta."<td style='display:none'>";
					        $respuesta = $respuesta.$r['num_med'];
				       $respuesta = $respuesta."</td>";
					   $respuesta = $respuesta."<td style='display:none'>";
					        $respuesta = $respuesta.$r['id_pac'];
				       $respuesta = $respuesta."</td>";
					    $respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fecha_consulta'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['hora_inicio'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['estatura'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['peso'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['sueño_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['examenf_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['complicacion_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['observacion_pac'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
	
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	private function existe($feccon){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			//AQUI COMENZAREMOS A HACER USO DE LO QUE SON LAS CONSULTAS PARAMETRIZABLES
			//PARA ELLO UTILIZAREMOS LA INSTRUCCIÓN Y AÑADIREMOS LOS PASOS PREPARE
			//Y EXECUTE PARA REGISTRAR O CONSULTAR EN LA BASE DE DATOS
			
			//ANTERIORMENTE ERA query(consuta sql)
			//$resultado = $co->query("Select * from paciente where fecha_consulta='$feccon'");
			
			//AHORA QUEDA
			$resultado = $co->prepare("SELECT * FROM consultas WHERE fecha_consulta=:feccon");
			//COMO VEN SE CAMBIO A $feccon QUE ES UNA VARIABLE QUE SE USA POR :feccon
			//QUE ES UN VALOR NO DECLARADO, POR LO QUE EL SIGUIETE PASO SERA 
			//INDICARLE A PHP QUIEN ES ESE :feccon Y PARA ELLO USAREMOS LA INSTRUCCION
			//bindParam QUE COLOCA UN VALOR EN :feccon Y EVITA QUE SE INCLUYAN 
			//INSTRUCCIONES QUE SE PUEDEN USAR EN MYSQL INJECT
			$resultado->bindParam(':feccon',$feccon);
			//YA SE TIENE EL VALOR DE :feccon
			//EL SIGUIENTE PASO ES EJUTAR LA CONSULTA
			
			$resultado->execute();
			
			//LO DEMAS QUEDA IGUAL
			$fila = $resultado->fetchAll(PDO::FETCH_BOTH);
			if($fila){

				return true;
			    
			}
			else{
				
				return false;;
			}
			
		}catch(Exception $e){
			return false;
		}
	}
	
	function listadoderepresentantes(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("SELECT * FROM medicos");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='colocarepresentante(this);'>";
						$respuesta = $respuesta."<td style='display:none'>";
							$respuesta = $respuesta.$r['id_medico'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['apellido_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['correo_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['horario_trabajo_doctor'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fecha_ingreso_doctor'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}

	function listadodeclientes(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from pacientes");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='colocacliente(this);'>";
						$respuesta = $respuesta."<td style='display:none'>";
						    $respuesta = $respuesta.$r['id_paciente'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_paciente'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fechadenacimiento'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['sexo'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['peso_nacimiento_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['estatura_nacimiento_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['desarrollo_psicomotor_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_pers_no_patologicos'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_heredo_familiar'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_prenatales_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_postnatales_pac'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
}

?>