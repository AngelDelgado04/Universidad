	<html> 
<?php require_once("comunes/encabezado.php"); ?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>
      
	<div id="contenidomed">
		<div class="card card-container">
      <div class="card-header">   	
				<div class="container text-center h2 text-black-50">
					Registro Consultas
				</div>
			</div>
    <div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
    <form method="post" action="" id="f">
    <input type="text" name="accion" id="accion" style="display:none"/>

	<div class="row">
		<div class="col">
		<hr/>
		</div>
	</div>
	<!-- FILA DE INPUT Y BUSCAR representante -->
	<div class="row">
		<div class="col-md-8 input-group">
		   <input class="form-control" type="text" id="cedularepresentante" name="cedularepresentante" placeholder="Ingrese la cedula del medico" />
		   <input class="form-control" type="text" id="idrepresentante" name="idrepresentante" style="display:none"/>
		   <button type="button" class="btn btn-primary" id="modalderepresentantes" name="modalderepresentantes">Lista de Medicos</button>
		</div>
	</div>
	<!-- FIN DE FILA INPUT Y BUSCAR representante -->
	
	<!-- FILA DE DATOS DEL representante -->
	<div class="row">
		<div class="col-md-12" id="datosdelrepresentante">
		   
		</div>
	</div>
	<!-- FIN DE FILA DATOS DEL representante -->
		
	<div class="row">
		<div class="col">
			<hr/>
		</div>
	</div>
          <div class="row">
		                <div class="col">
							<label for="cedulacliente">Cedula del paciente</label>
		                    <input class="form-control" type="text" id="cedulacliente" name="cedulacliente" placeholder="cedula del paciente"/>
		                    <input class="form-control" type="text" id="idcliente" name="idcliente" style="display:none"/>
		                </div>

						<div class="col">
							<label for="horincon">Hora de la consulta</label>
							<input class="form-control" type="time" id="horincon" name="horincon"  
							required  
							title="Horario consulta"/>
							<span id="shorincon"></span>
						</div>
						
						
						<div class="col">
							<label for="feccon">Fecha de la consulta</label>
							<input class="form-control" type="date" id="feccon" name="feccon"  
							value="<?php 
						    $f = date('Y-m-d');
						    $f1 = strtotime ('-1 year' , strtotime($f)); 
					        $f1 = date ('Y-m-d',$f1);
					        echo $f1; ?>"
		                    />
							<span id="sfeccon"></span>
						</div>
					</div>

					<!-- FILA DE DATOS DEL CLIENTE -->
	<div class="row">
		<div class="col" id="datosdelcliente">  
		</div>
	</div>
	<!-- FIN DE FILA DATOS DEL CLIENTE -->

					<div class="row">
						<div class="col">
							<label for="pesocon">Peso del paciente</label>
							<input class="form-control" type="text" id="pesocon" name="pesocon"/>
							<span id="spesocon"></span>
						</div>
						
						<div class="col">
							<label for="estcon">Estatura del paciente</label>
							<input class="form-control" type="text" id="estcon" name="estcon"/>
							<span id="sestcon"></span>
						</div>
						
						<div class="col">
							<label for="hordorm">Horas que duerme el paciente</label>
							<input class="form-control" type="text" id="hordorm" name="hordorm"/>
							<span id="shordorm"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<label for="examenfis">Examen físico del paciente</label>
							<input class="form-control" type="text" id="examenfis" name="examenfis"/>
							<span id="sexamenfis"></span>
						</div>

						<div class="col">
							<label for="comppac">Complicaciones del paciente</label>
							<input class="form-control" type="text" id="comppac" name="comppac"/>
							<span id="scomppac"></span>
						</div>

						<div class="col">
							<label for="observaciones">Observaciones</label>
							<input class="form-control" type="text" id="observaciones" name="observaciones"/>
							<span id="sobservaciones"></span>
						</div>
					</div>
					
	<div class="row">
		<div class="col">
			<hr/>
		</div>
	</div>

        <div class="card-footer text-muted"> <!-- inicio de los botones -->
				  <div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
			        <button type="button" class="btn btn-primary" id="consultar" 
			         data-toggle="modal" data-target="#modal1" name="consultar">CONSULTAR</button>
		        </div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
</div><!-- fin del container que engloba todo -->
</form>

		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->


<!-- seccion del modal representantes -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modalrepresentantes">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de Medicos</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		    <th style="display:none">Id</th>
			<th>Cedula</th>
			<th>Nombre</th>
			<th>Apellido</th>
			<th>Correo</th>
			<th>Hor. de Trabajo</th>
			<th>Fec. ingreso</th>


		  </tr>
		</thead>
		<tbody id="listadoderepresentantes">
		  <?php
			if(!empty($consultarepresentantes)){
				echo $consultarepresentantes;
			}
		  ?>
		</tbody>
		</table>
    </div>
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->

<!-- seccion del modal -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modal1">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de Consulta</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		  <th>Fecha Consulta</th>
		  <th>Hora Consulta</th>
			<th>Peso.</th>
			<th>Estatura</th>
			<th>Horas sueño</th>
			<th>Exam. Fisico</th>
			<th>Complicación</th>
			<th>Observaciones</th>
		  </tr>
		</thead>
		<tbody>
		  <?php
			if(!empty($consulta)){
				echo $consulta;
			}
		  ?>
		</tbody>
		</table>
    </div>
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->



<script type="text/javascript" src="js/consultas.js"></script>

</body>
</html>