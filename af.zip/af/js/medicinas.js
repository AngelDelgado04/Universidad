
$(document).ready(function(){

//Seccion para mostrar lo enviado en el modal mensaje//

//Función que verifica que exista algo dentro de un div
//oculto y lo muestra por el modal
if($.trim($("#mensajes").text()) != ""){
	muestraMensaje($("#mensajes").html());
}
//Fin de seccion de mostrar envio en modal mensaje//	
	
//VALIDACION DE DATOS	
	
	
	$("#nmed").on("keypress",function(e){
		validarkeypress(/^[0-9]*$/,e);
	});
	
	$("#nmed").on("keyup",function(){
		validarkeyup(/^[0-9]{4}$/,
		$(this),$("#snmed"),"Solo numeros ejemplo 0001");
	});

	$("#nombremed").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#nombremed").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,20}$/,$(this),
		$("#snombremed"),"Solo letras entre 3 y 20 caracteres");
	});
	
	$("dosism").on("keypress",function(e){
		validarkeypress(/^[0-9\b]*$/,e);
	});

	$("#dosism").on("keyup",function(){
		validarkeyup(/^[0-9]{1,5}$/,$(this),
		$("#sdosism"),"Solo numeros. Ejemplo 500");
	});
	
//FIN DE VALIDACION DE DATOS

//CONTROL DE BOTONES

$("#incluir").on("click",function(){
	if(validarenvio()){
		$("#accion").val("incluir");	
		$("#f").submit();
	}
});
$("#modificar").on("click",function(){
	if(validarenvio()){
		$("#accion").val("modificar");	
		$("#f").submit();
	}
});
$("#eliminar").on("click",function(){

	if(validarkeyup(/^[0-9]{4}$/,$("#nmed"),
		$("#snmed"),"Solo numeros ejemplo 0001")==0){
		muestraMensaje("Num. de Med. <br/>Ejemplo 0001");
		
	}	
		
	
	else{	
		$("#accion").val("eliminar");	
		$("#f").submit();
	}
	
});
//FIN DE CONTROL DE BOTONES	

});

//Validación de todos los campos antes del envio
function validarenvio(){
		
	if(validarkeyup(/^[0-9]{4}$/,
		$("#nmed"),$("#snmed"),"Solo numeros ejemplo 0001")==0){
		muestraMensaje("Solo numeros <br/>Ejemplo 0001");
		return false;
	}
	
	else if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,20}$/,$("#nombremed"),
		$("#snombremed"),"Solo numeros ejemplo 0001")==0){
		muestraMensaje("Nombre de Med. <br/>Ejemplo Acetaminofen");
		return false;
	}

	else if(validarkeyup(/^[0-9]{1,5}$/,$("#dosism"),
		$("#sdosism"),"Solo numeros")==0){
		muestraMensaje("Dosis de Med. <br/>Ejemplo 500");
		return false;
	}
	
	return true;
}


//Funcion que muestra el modal con un mensaje
function muestraMensaje(mensaje){
	$("#contenidodemodal").html(mensaje);
			$("#mostrarmodal").modal("show");
			setTimeout(function() {
					$("#mostrarmodal").modal("hide");
			},4000);
}


//Función para validar por Keypress
function validarkeypress(er,e){
	
	key = e.keyCode;
	
	
    tecla = String.fromCharCode(key);
	
	
    a = er.test(tecla);
	
    if(!a){
	
		e.preventDefault();
    }
	
    
}
//Función para validar por keyup
function validarkeyup(er,etiqueta,etiquetamensaje,
mensaje){
	a = er.test(etiqueta.val());
	if(a){
		etiquetamensaje.text("");
		return 1;
	}
	else{
		etiquetamensaje.text(mensaje);
		return 0;
	}
}

function coloca(linea){
	$("#nmed").val($(linea).find("td:eq(0)").text());
	$("#nombremed").val($(linea).find("td:eq(1)").text());
	$("#disponibilidad").val($(linea).find("td:eq(2)").text());
	$("#tmed").val($(linea).find("td:eq(3)").text());
	$("#dosism").val($(linea).find("td:eq(4)").text());

}
