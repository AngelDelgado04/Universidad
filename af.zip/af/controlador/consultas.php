<?php
  
//llamada al archivo que contiene la clase
//usuarios, en ella estara el codigo que me //permitirá
//guardar, consultar y modificar dentro de mi base //de datos


//lo primero que se debe hacer es verificar al //igual que en la vista que exista el archivo
if (!is_file("modelo/".$pagina.".php")){
  //alli pregunte que si no es archivo se niega //con !
  //si no existe envio mensaje y me salgo
  echo "Falta definir la clase ".$pagina;
  exit;
}  
require_once("modelo/".$pagina.".php");  
  if(is_file("vista/".$pagina.".php")){
    
    
    
    
    $o = new consultas(); 
    
    
    $consultarepresentantes = $o->listadoderepresentantes();
    $consultaclientes = $o->listadodeclientes();

    if(!empty($_POST)){
      
      //como ya sabemos si estamos aca es //porque se recibio alguna informacion
      //de la vista, por lo que lo primero que //debemos hacer ahora que tenemos una 
      //clase es guardar esos valores en ella //con los metodos set
      $accion = $_POST['accion'];
      $o->set_idrepresentante($_POST['idrepresentante']);
      $o->set_idcliente($_POST['idcliente']);
      $o->set_feccon($_POST['feccon']);
      $o->set_horincon($_POST['horincon']);
      $o->set_pesocon($_POST['pesocon']);
      $o->set_estcon($_POST['estcon']);
      $o->set_hordorm($_POST['hordorm']);
      $o->set_examenfis($_POST['examenfis']);
      $o->set_comppac($_POST['comppac']);
      $o->set_observaciones($_POST['observaciones']);

        
      if($accion=='incluir'){
      $mensaje =  $o->incluir();
      }
      elseif($accion=='modificar'){
      $mensaje =  $o->modificar();
      
      }
      elseif($accion=='eliminar'){
      $mensaje =  $o->eliminar();
      
      }
    }
    $consulta = $o->consultar();

    
    require_once("vista/".$pagina.".php"); 
  }
  else{
    echo "pagina en construccion";
  }
?>
