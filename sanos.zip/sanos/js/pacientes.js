
$(document).ready(function(){
//para mostrar en modal mensajes del servidor	
if($.trim($("#mensajes").text()) != ""){
	muestraMensaje($("#mensajes").html());
}
//Fin de seccion de mostrar envio en modal mensaje//	
	
//boton para levantar modal de representantes
$("#modalderepresentantes").on("click",function(){
	$("#modalrepresentantes").modal("show");
});



//evento keyup de input cedularepresentante	
$("#cedularepresentante").on("keyup",function(){
	var cedula = $(this).val();
	var encontro = false;
	$("#listadoderepresentantes tr").each(function(){
		if(cedula == $(this).find("td:eq(1)").text()){
			colocarepresentante($(this));
			encontro = true;
		} 
	});
	if(!encontro){
		$("#datosdelrepresentante").html("");
	}
});	


	
	
});


//function para buscar si existe el representante 
function existerepresentante(){
	var cedula = $("#cedularepresentante").val();
	var existe = false;
	$("#listadoderepresentantes tr").each(function(){
		if(cedula == $(this).find("td:eq(1)").text()){
			existe = true;
		}
	});
	
	return existe;
	
}
//fin de funcion existerepresentante








//funcion para colocar datos del representante en pantalla
function colocarepresentante(linea){
	$("#cedularepresentante").val($(linea).find("td:eq(1)").text());
	$("#idrepresentante").val($(linea).find("td:eq(0)").text());
	$("#datosdelrepresentante").html($(linea).find("td:eq(2)").text()+
	"  "+$(linea).find("td:eq(3)").text()+"  "+
	$(linea).find("td:eq(4)").text());
}

//fin de colocar datos del representante



//Funcion que muestra el modal con un mensaje
function muestraMensaje(mensaje){
	$("#contenidodemodal").html(mensaje);
			$("#mostrarmodal").modal("show");
			setTimeout(function() {
					$("#mostrarmodal").modal("hide");
			},5000);
}


//Función para validar por Keypress
function validarkeypress(er,e){
	
	key = e.keyCode;
	
	
    tecla = String.fromCharCode(key);
	
	
    a = er.test(tecla);
	
    if(!a){
	
		e.preventDefault();
    }
	
    
}
//Función para validar por keyup
function validarkeyup(er,etiqueta,etiquetamensaje,
mensaje){
	a = er.test(etiqueta.val());
	if(a){
		etiquetamensaje.text("");
		return 1;
	}
	else{
		etiquetamensaje.text(mensaje);
		return 0;
	}
}




//funcion para limpiar la pantalla
function limpia(){

	$("#cedularepresentante").val('');
	$("#idrepresentante").val('');

	$("#datosdelrepresentante").html('');
}
