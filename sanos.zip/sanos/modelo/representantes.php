<?php
//llamda al archivo que contiene la clase
//datos, en ella posteriormente se colcora el codigo
//para enlazar a su base de datos
require_once('modelo/datos.php');

//declaracion de la clase usuarios que hereda de la clase datos
//la herencia se declara con la palabra extends y no es mas 
//que decirle a esta clase que puede usar los mismos metodos
//que estan en la clase de dodne hereda (La padre) como sir fueran de el

class representantes extends datos{
	//el primer paso dentro de la clase
	//sera declarar los atributos (variables) que describen la clase
	//para nostros no es mas que colcoar los inputs (controles) de
	//la vista como variables aca
	//cada atributo debe ser privado, es decir, ser visible solo dentro de la
	//misma clase, la forma de colcoarlo privado es usando la palabra private
	
	private $cedula; //recuerden que en php, las variables no tienen tipo predefinido
	private $nombre;
	private $apellido;
	private $telefono;
	private $antcper;
	private $correo;
	
	//Ok ya tenemos los atributos, pero como son privados no podemos acceder a ellos desde fueran
	//por lo que debemos colcoar metodos (funciones) que me permitan leer (get) y colocar (set)
	//valores en ello, esto es  muy mal llamado geters y seters por si alguien se los pregunta
	
	function set_cedula($valor){
		$this->cedula = $valor; //fijencen como se accede a los elementos dentro de una clase
		//this que singnifica esto es decir esta clase luego -> simbolo que indica que apunte
		//a un elemento de this, es decir esta clase
		//luego el razon del elemento sin el $
	}
	//lo mismo que se hizo para cedula se hace para usuario y clave
	
	function set_nombre($valor){
		$this->nombre = $valor;
	}

	function set_apellido($valor){
		$this->apellido = $valor;
	}
	
	function set_telefono($valor){
		$this->telefono = $valor;
	}
	
	function set_antcper($valor){
		$this->antcper = $valor;
	}
	
	function set_correo($valor){
		$this->correo = $valor;
	}
	
	//Lo siguiente que demos hacer es crear los metodos para incluir, consultar y eliminar
	
	function incluir(){
		//Ok ya tenemos la base de datos y la funcion conecta dentro de la clase
		//datos, ahora debemos ejecutar las operaciones para realizar las consultas 
		
		//Lo primero que debemos hacer es consultar por el campo clave
		//en este caso la cedula, para ello se creo la funcion existe
		//que retorna true en caso de exitir el registro
		
		if(!$this->existe($this->cedula)){
			//si estamos aca es porque la cedula no existe es decir se puede incluir
			//los pasos a seguir son
			//1 Se llama a la funcion conecta 
			$co = $this->conecta();
			$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//2 Se ejecuta el sql
			try {
					$r = $co->prepare("Insert into representante(
						nombre,
						apellido,
						cedula_representantes,
						telefono_representantes,
						antecedentes_personales,
						correo
						)
						Values(
						:nombre,
						:apellido,
						:cedula,
						:telefono,
						:antcper,
						:correo
						)");
						
					$r->bindParam(':nombre',$this->nombre);
					$r->bindParam(':apellido',$this->apellido);	
					$r->bindParam(':cedula',$this->cedula);	
					$r->bindParam(':telefono',$this->telefono);
					$r->bindParam(':antcper',$this->antcper);	
					$r->bindParam(':correo',$this->correo);	
					
					$r->execute();
					
						return "Registro incluido";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Ya existe el cedula que desea ingresar";
		}
		
		//Listo eso es todo y es igual para el resto de las operaciones
		//incluir, modificar y eliminar
		//solo cambia para buscar 
	}
	
	function modificar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->cedula)){
			try {
					$r = $co->prepare("Update representante set 
					    nombre = :nombre,
					    apellido = :apellido,
						telefono_representantes = :telefono,
						antecedentes_personales = :antcper,
						correo = :correo
						where
						cedula_representantes = :cedula
						");
						
					$r->bindParam(':nombre',$this->nombre);
					$r->bindParam(':apellido',$this->apellido);	
					$r->bindParam(':telefono',$this->telefono);
					$r->bindParam(':antcper',$this->antcper);	
					$r->bindParam(':correo',$this->correo);		
					$r->bindParam(':cedula',$this->cedula);	
					
					$r->execute();
						
						
						
						return "Registro Modificado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "cedula no registrada";
		}
		
	}
	
	function eliminar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->cedula)){
			try {
					$r = $co->prepare("Delete from representante 
						where
						cedula_representantes = :cedula
						");
					$r->bindParam(':cedula',$this->cedula);	
					
					$r->execute();
					
						return "Registro Eliminado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "cedula no registrada";
		}
	}
	
	
	function consultar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from representante");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='coloca(this);'>";
					    $respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_representantes'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['apellido'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['telefono_representantes'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['antecedentes_personales'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['correo'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	private function existe($cedula){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			//AQUI COMENZAREMOS A HACER USO DE LO QUE SON LAS CONSULTAS PARAMETRIZABLES
			//PARA ELLO UTILIZAREMOS LA INSTRUCCIÓN Y AÑADIREMOS LOS PASOS PREPARE
			//Y EXECUTE PARA REGISTRAR O CONSULTAR EN LA BASE DE DATOS
			
			//ANTERIORMENTE ERA query(consuta sql)
			//$resultado = $co->query("Select * from representantes where cedula_representantes='$cedula'");
			
			//AHORA QUEDA
			$resultado = $co->prepare("Select * from representantes where cedula_representantes=:cedula");
			//COMO VEN SE CAMBIO A $cedula QUE ES UNA VARIABLE QUE SE USA POR :cedula
			//QUE ES UN VALOR NO DECLARADO, POR LO QUE EL SIGUIETE PASO SERA 
			//INDICARLE A PHP QUIEN ES ESE :cedula Y PARA ELLO USAREMOS LA INSTRUCCION
			//bindParam QUE COLOCA UN VALOR EN :cedula Y EVITA QUE SE INCLUYAN 
			//INSTRUCCIONES QUE SE PUEDEN USAR EN MYSQL INJECT
			$resultado->bindParam(':cedula',$cedula);
			//YA SE TIENE EL VALOR DE :cedula
			//EL SIGUIENTE PASO ES EJUTAR LA CONSULTA
			
			$resultado->execute();
			
			//LO DEMAS QUEDA IGUAL
			$fila = $resultado->fetchAll(PDO::FETCH_BOTH);
			if($fila){

				return true;
			    
			}
			else{
				
				return false;;
			}
			
		}catch(Exception $e){
			return false;
		}
	}


	
	
	
}
?>