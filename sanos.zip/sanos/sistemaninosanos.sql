-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-02-2022 a las 21:02:17
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistemaninosanos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta`
--

CREATE TABLE `consulta` (
  `num_control_consulta` int(11) NOT NULL,
  `num_medico` int(11) NOT NULL,
  `horario_inicio` time NOT NULL,
  `horario_final` time NOT NULL,
  `fecha_consulta` date NOT NULL,
  `peso_consulta` float NOT NULL,
  `estatura_consulta` float NOT NULL,
  `dia_ingreso_consulta` date NOT NULL,
  `num_historia` int(11) NOT NULL,
  `sueño_pac` time NOT NULL,
  `examenes_fisicos_pac` varchar(20) NOT NULL,
  `complicacion_pac` varchar(50) NOT NULL,
  `medicinas_pac` varchar(50) NOT NULL,
  `examenes_pac` varchar(50) NOT NULL,
  `frecuencia_alimenticia_pac` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctor`
--

CREATE TABLE `doctor` (
  `num_medico` int(11) NOT NULL,
  `cedula_doctor` int(12) NOT NULL,
  `nombre_doctor` varchar(20) NOT NULL,
  `apellido_doctor` varchar(20) NOT NULL,
  `correo_doctor` varchar(50) DEFAULT NULL,
  `num_telefonico` int(11) NOT NULL,
  `horario_trabajo_doctor` varchar(20) NOT NULL,
  `fecha_ingreso_doctor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen`
--

CREATE TABLE `examen` (
  `num_examen` int(11) NOT NULL,
  `nombre_examen` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen_consulta`
--

CREATE TABLE `examen_consulta` (
  `num_examen` int(11) NOT NULL,
  `num_control_consulta` int(11) NOT NULL,
  `fecha_examen` time NOT NULL,
  `tipo_examen` varchar(50) NOT NULL,
  `resultado_examen` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicina`
--

CREATE TABLE `medicina` (
  `num_medicina` int(11) NOT NULL,
  `nombre_medicina` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicina_consulta`
--

CREATE TABLE `medicina_consulta` (
  `num_medicina` int(11) NOT NULL,
  `num_control_consulta` int(11) NOT NULL,
  `tipo_medicina` varchar(50) NOT NULL,
  `alergia_medicina` varchar(20) NOT NULL,
  `dosis_al_dia` float NOT NULL,
  `cantidad_tiempo_dosis` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE `paciente` (
  `cedula_paciente` int(11) NOT NULL,
  `nombre_pac` varchar(20) NOT NULL,
  `apellido_pac` varchar(20) NOT NULL,
  `direccion_pac` varchar(50) NOT NULL,
  `fecha_nacimiento_pac` date NOT NULL,
  `peso_nacimiento_pac` int(11) NOT NULL,
  `estatura_nacimiento_pac` float NOT NULL,
  `desarrollo_psicomotor_pac` varchar(20) NOT NULL,
  `cedula_representante` varchar(12) NOT NULL,
  `antec_pers_no_patologicos` varchar(50) NOT NULL,
  `antecedentes_familiares` varchar(50) NOT NULL,
  `antec_heredo_familiar` varchar(20) NOT NULL,
  `antec_prenatales_pac` varchar(20) NOT NULL,
  `antec_perinatales_pac` varchar(20) NOT NULL,
  `antec_postnatales_pac` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacientes_vacunas`
--

CREATE TABLE `pacientes_vacunas` (
  `num_historia` int(11) NOT NULL,
  `codigo_vacuna` int(11) NOT NULL,
  `fecha_vacunacion` date NOT NULL,
  `dosis_vacuna` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representante`
--

CREATE TABLE `representante` (
  `id_representantes` int(11) NOT NULL,
  `cedula_representantes` varchar(12) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `telefono_representantes` varchar(12) NOT NULL,
  `antecedentes_personales` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `representante`
--

INSERT INTO `representante` (`id_representantes`, `cedula_representantes`, `nombre`, `apellido`, `correo`, `telefono_representantes`, `antecedentes_personales`) VALUES
(1, 'V-12848898', 'Lila Peña', 'YEPEZ RAMONES', 'carlosgomez2946@gmail.com', '121-2122121', 'asasasasa'),
(2, 'V-111111111', 'Lila Peña', 'Peña Flores', 'carlosgomez2946@gmail.com', '121-2122121', 'asasasasa'),
(3, 'V-111111112', 'assasa', 'asdasd', 'alguien@servidor.com', '0416-7571775', 'asasasasa'),
(4, 'V-111111113', 'sddds', 'saasdas', 'alguien@servidor.com', '121-2122121', 'sadsad'),
(5, 'V-24613207', 'Yeisson', 'Angulo', 'carlosgomez2946@gmail.com', '121-2122121', 'asasasasa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vacunas`
--

CREATE TABLE `vacunas` (
  `codigo_vacuna` int(11) NOT NULL,
  `nombre_vacuna` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD PRIMARY KEY (`num_control_consulta`),
  ADD KEY `num_medico` (`num_medico`),
  ADD KEY `num_historia` (`num_historia`);

--
-- Indices de la tabla `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`num_medico`),
  ADD UNIQUE KEY `cedula_doctor` (`cedula_doctor`);

--
-- Indices de la tabla `examen`
--
ALTER TABLE `examen`
  ADD PRIMARY KEY (`num_examen`);

--
-- Indices de la tabla `examen_consulta`
--
ALTER TABLE `examen_consulta`
  ADD PRIMARY KEY (`num_examen`),
  ADD KEY `num_control_consulta` (`num_control_consulta`);

--
-- Indices de la tabla `medicina`
--
ALTER TABLE `medicina`
  ADD PRIMARY KEY (`num_medicina`);

--
-- Indices de la tabla `medicina_consulta`
--
ALTER TABLE `medicina_consulta`
  ADD PRIMARY KEY (`num_medicina`),
  ADD KEY `num_control_consulta` (`num_control_consulta`);

--
-- Indices de la tabla `pacientes_vacunas`
--
ALTER TABLE `pacientes_vacunas`
  ADD PRIMARY KEY (`num_historia`,`codigo_vacuna`),
  ADD KEY `codigo_vacuna` (`codigo_vacuna`);

--
-- Indices de la tabla `representante`
--
ALTER TABLE `representante`
  ADD PRIMARY KEY (`id_representantes`),
  ADD UNIQUE KEY `cedula_representantes` (`cedula_representantes`);

--
-- Indices de la tabla `vacunas`
--
ALTER TABLE `vacunas`
  ADD PRIMARY KEY (`codigo_vacuna`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `representante`
--
ALTER TABLE `representante`
  MODIFY `id_representantes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD CONSTRAINT `consulta_ibfk_1` FOREIGN KEY (`num_medico`) REFERENCES `doctor` (`num_medico`) ON DELETE CASCADE,
  ADD CONSTRAINT `consulta_ibfk_2` FOREIGN KEY (`num_historia`) REFERENCES `paciente` (`cedula_paciente`) ON DELETE CASCADE;

--
-- Filtros para la tabla `examen_consulta`
--
ALTER TABLE `examen_consulta`
  ADD CONSTRAINT `examen_consulta_ibfk_1` FOREIGN KEY (`num_control_consulta`) REFERENCES `consulta` (`num_control_consulta`) ON DELETE CASCADE,
  ADD CONSTRAINT `examen_consulta_ibfk_2` FOREIGN KEY (`num_examen`) REFERENCES `examen` (`num_examen`) ON DELETE CASCADE;

--
-- Filtros para la tabla `medicina_consulta`
--
ALTER TABLE `medicina_consulta`
  ADD CONSTRAINT `medicina_consulta_ibfk_1` FOREIGN KEY (`num_control_consulta`) REFERENCES `consulta` (`num_control_consulta`) ON DELETE CASCADE,
  ADD CONSTRAINT `medicina_consulta_ibfk_2` FOREIGN KEY (`num_medicina`) REFERENCES `medicina` (`num_medicina`) ON DELETE CASCADE;

--
-- Filtros para la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD CONSTRAINT `paciente_ibfk_1` FOREIGN KEY (`cedula_representante`) REFERENCES `representante` (`cedula_representantes`) ON DELETE CASCADE;

--
-- Filtros para la tabla `pacientes_vacunas`
--
ALTER TABLE `pacientes_vacunas`
  ADD CONSTRAINT `pacientes_vacunas_ibfk_1` FOREIGN KEY (`num_historia`) REFERENCES `paciente` (`cedula_paciente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pacientes_vacunas_ibfk_2` FOREIGN KEY (`codigo_vacuna`) REFERENCES `vacunas` (`codigo_vacuna`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
