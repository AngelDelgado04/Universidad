<html> 
<?php require_once("comunes/encabezado.php"); ?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<div class="card card-container">
			<div class="card-header">
				<div class="container text-center h2 text-black-50">
					Registrar Paciente
				</div>
			</div>
			<form method="post" action="" id="f">
				<!--Caja de entrada invisible para indicar al servidor que boton fue pulsado-->
				<input type="text" name="accion" id="accion" style="display:none"/>
				<div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
					<hr/>

	<!-- FILA DE INPUT Y BUSCAR REPRESENTANTES -->
	<div class="row">
		<div class="col-md-8 input-group">
		   <input class="form-control" type="text" id="cedularepresentante" name="cedularepresentante" />
		   <input class="form-control" type="text" id="idrepresentante" name="idrepresentante" style="display:none"/>
		   <button type="button" class="btn btn-primary" id="modalderepresentantes" name="modalderepresentantes">Lista de representantes</button>
		</div>
	</div>
	<!-- FIN DE FILA INPUT Y BUSCAR REPRESENTANTES -->
	
	<!-- FILA DE DATOS DEL REPRESENTANTES -->
	<div class="row">
		<div class="col-md-12" id="datosdelrepresentante">
		   
		</div>
	</div>
	<!-- FIN DE FILA DATOS DEL REPRESENTANTES -->
		
	<div class="row">
		<div class="col">
			<hr/>
		</div>
	</div>
</div>
</form>
	</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->


<!-- seccion del modal representantes -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modalrepresentantes">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de representantes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		    <th style="display:none">Id</th>
		  <th>Cedula</th>
		  <th>Nombre</th>
			<th>Apellido</th>
			<th>Telefono</th>
			<th>Correo</th>
			<th>Antecedentes Personales</th>
			
		  </tr>
		</thead>
		<tbody id="listadoderepresentantes">
		  <?php
			if(!empty($consultarepresentantes)){
				echo $consultarepresentantes;
			}
		  ?>
		</tbody>
		</table>
    </div>
    
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->


<script type="text/javascript" src="js/pacientes.js"></script>

</body>
</html>