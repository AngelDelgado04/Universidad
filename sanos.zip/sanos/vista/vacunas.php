<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body class="contenedor">
	<!--Div oculta para colocar el mensaje a mostrar-->	

	<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<hr>
		<div class="card card-container">
			<div class="card-header">
				<div class="container text-center h2 text-black-50">
					Inventario de Vacunas
				</div>
			</div>
			<form method="post" action="" id="f">
				<!--Caja de entrada invisible para indicar al servidor que boton fue pulsado-->
				<input type="text" name="accion" id="accion" style="display:none"/>
				<div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
					
					<div class="row">
						<div class="col">
							<label for="codvacuna">Codigo de la vacuna</label>
							<input class="form-control" type="text" id="codvacuna" name="codvacuna" 
							pattern="[0-9]{5,7}"
							required 
							maxlength="7" 
							minlength="5" 
							title="Solo numeros entre 5 y 7"/>
							<span id="scodvacuna"></span>
						</div>

					    <div class="col">
							<label for="medalergia">Nombre de las vacunas</label>
							<input class="form-control" type="text" id="vacunas" name="vacunas"  
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{15,20}" 
							required 
							maxlength="20" 
							minlength="15" 
							title="Vacunas disponibles"/>
							<span id="svacunas"></span>
					    </div>
				    </div>

				    <div class="row">
				    	<div class="col">
				    		<hr/>
				    	</div>
				    </div>
				</div> <!-- fin del container -->

				<div class="card-footer text-muted"> <!-- inicio de los botones -->
						<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
			</form>
			<div  class="container">
				<div class="row">
					<div class="col text-center">
						<?php
						if(!empty($mensaje)){
							echo $mensaje;
						}
						?>	
					</div>
				</div>
			</div>
		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->
	<script src="js/select-checkbox.js"></script>
</body>
</html>