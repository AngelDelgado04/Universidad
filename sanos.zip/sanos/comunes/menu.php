<link rel="stylesheet" href="css/styles.css">

<nav class="navbar navbar-expand-lg col py-0">
   
    <button class="navbar-toggler" type="button" data-toggle="collapse"  
    data-target="#navbarNavDropdown" 
    aria-controls="navbarNavDropdown" aria-expanded="false" 
    aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button> 
<img src="img/principal.jpg" alt="" style="width:50px;">
<label class="navbar-brand">Amb</label>
<div class="collapse navbar-collapse" id="navbarNavDropdown">

  <?php  

  if(empty($_SESSION)){
      session_start();
  }
  
  if(isset($_SESSION['nivel'])){
     $nivel = $_SESSION['nivel'];
 }   
 else{
    $nivel = "";
}
?>  

<ul class="navbar-nav ml-auto">
       <?php
        if($nivel !== ""){
      ?>

        <li class="nav-item">

           <?php
             if($nivel == "admin" or $nivel == "user"){
          ?>
          <a class="nav-link" href="?pagina=medicos" id="navbardrop">
          Movimientos
          </a>
          <?php
             }
          ?>
        </li>
          <?php
             }
          ?>
     </ul>

<?php
if($nivel == "admin" or $nivel == "user"){
?>
<a href="?pagina=salida" class="text-dark text-decoration-none"><img src="img/perfil.png" alt="" width="32" height="32" class="rounded-circle me-2"> <strong>Cerrar Sesión</strong></a>
<?php  
}
else{
?>
<div>

<a href="?pagina=entrada" class="text-dark text-decoration-none"><img src="img/perfil.png" alt="" width="32" height="32" class="rounded-circle me-2"> <strong>Inicio de Sesión</strong></a>
</div>
<?php     
}
?>
</div>  
</nav>


