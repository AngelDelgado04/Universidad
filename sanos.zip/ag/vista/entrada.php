<html>
<link rel="stylesheet" href="css/login.css">
<?php require_once("comunes/encabezado.php"); ?>
<body>
  <?php require_once('comunes/menu.php'); ?>

  <div id="contenidomed">

    <div class="container">
      <?php
      if(!empty($mensaje)){
        ?>
        <div class="row">
         <div class="col-12">  
           <div class="sticky-top alert alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php
            echo $mensaje;
            ?>
          </div>
        </div>
      </div>
      <?php
    }
    ?>
  </div>


  <div class="container-fluid">
    <div class="row no-gutter">
      <!-- Imagen -->
      <div class="col-md-6 d-none d-md-flex bg-imagen"></div>

      <!-- Contenido -->
      <div class="col-md-6 bg-light"> 
        <div class="login d-flex align-items-center py-5">

          <div class="container">  <!-- Aqui todo el contenido -->
            <div class="row"> <!-- Fila -->
              <div class="col-lg-10 col-xl-7 mx-auto">
                <h3 class="display-8 text-center">Ingrese al sistema</h3>
                <p class="text-muted mb-4 text-center">Bienvenido</p>

                <form method="post" action="" id="f">
                  <!--Caja de entrada invisible para indicar al servidor que boton fue pulsado-->
                  <input type="text" name="accion" id="accion" style="display:none"/>

                  <div class="form-group mb-3">
                    <input id="cedula" name="cedula" type="text" placeholder="Ingrese su cedula" class="form-control rounded-pill border-0 shadow-sm px-4"/>     
                    <span id="scedula"></span>
                  </div>

                  <div class="form-group mb-3">
                    <input id="usuario" name="usuario" type="text" placeholder="Ingrese su usuario" class="form-control rounded-pill border-0 shadow-sm px-4"/>     
                    <span id="susuario"></span>
                  </div>

                  <div class="form-group mb-3">
                    <input id="contraseña" type="password" placeholder="Ingrese su contraseña"
                    class="form-control rounded-pill border-0 shadow-sm px-4 text-primary"/> 
                    <span id="scontraseña"></span>      
                  </div>
                  <div class="custom-control custom-checkbox mb-3">
                    <input id="rcontraseña" type="checkbox" checked class="custom-control-input">
                    <label for="rcontraseña" class="custom-control-label">Recordar contraseña</label>
                  </div>

                  <button type="submit" id="entrar" name="entrar" class="btn btn-success btn-block text-uppercase mb-2 rounded-pill shadow-sm">Iniciar Sesión</button>

                  <a href="?pagina=registro" class="btn btn-success btn-block text-uppercase mb-2 rounded-pill shadow-sm">Registre su Usuario</a>

                
                </div>

              </div> <!-- Cierre de la fila -->
            </div><!-- Cierre del container dentro del form -->

          </div>
        </div> <!-- Cierre del div que engloba el contenido -->

      </div>
    </div>
  </div>
  <script type="text/javascript" src="js/entrada.js"></script>

</body>
</html>