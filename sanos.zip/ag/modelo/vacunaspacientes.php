<?php

require_once('modelo/datos.php');



class paciente_v extends datos{

	private $fecvacuna; //recuerden que en php, las variables no tienen tipo predefinido
	private $dosisvacuna;
	private $cedulacliente;
	private $cedularepresentante;

	
	
	//Ok ya tenemos los atributos, pero como son privados no podemos acceder a ellos desde fueran
	//por lo que debemos colcoar metodos (funciones) que me permitan leer (get) y colocar (set)
	//valores en ello, esto es  muy mal llamado geters y seters por si alguien se los pregunta
	
	function set_fecvacuna($valor){
		$this->fecvacuna = $valor; //fijencen como se accede a los elementos dentro de una clase
		//this que singnifica esto es decir esta clase luego -> simbolo que indica que apunte
		//a un elemento de this, es decir esta clase
		//luego el razon del elemento sin el $
	}
	//lo mismo que se hizo para fecvacuna se hace para usuario y clave
	
	function set_dosisvacuna($valor){
		$this->dosisvacuna = $valor;
	}
	function set_cedulacliente($valor){
		$this->cedulacliente = $valor;
	}
	function set_cedularepresentante($valor){
		$this->cedularepresentante = $valor;
	}
	
	
	//Lo siguiente que demos hacer es crear los metodos para incluir, consultar y eliminar
	
	function incluir(){
		//Ok ya tenemos la base de datos y la funcion conecta dentro de la clase
		//datos, ahora debemos ejecutar las operaciones para realizar las consultas 
		
		//Lo primero que debemos hacer es consultar por el campo clave
		//en este caso la fecvacuna, para ello se creo la funcion existe
		//que retorna true en caso de exitir el registro
		
		if(!$this->existe($this->fecvacuna)){
			//si estamos aca es porque la fecvacuna no existe es decir se puede incluir
			//los pasos a seguir son
			//1 Se llama a la funcion conecta 
			
			$co = $this->conecta();
			$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//2 Se ejecuta el sql
			try {
					$r = $co->prepare("Insert into pacientesvac(
						fecha_vacunacion,
						dosis_vacuna,
						id_paciente,
						id_vacuna
						)
						Values(
						:dosisvacuna,
						:fecvacuna,
						:cedulacliente,
						:cedularepresentante
						)");
						
					$r->bindParam(':dosisvacuna',$this->dosisvacuna);
					$r->bindParam(':fecvacuna',$this->fecvacuna);
					$r->bindParam(':cedulacliente',$this->cedulacliente);
					$r->bindParam(':cedularepresentante',$this->cedularepresentante);	
	
						
					$r->execute();
					
						return "Registro incluido";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Ya existe la fecha que desea ingresar";
		}
		
		//Listo eso es todo y es igual para el resto de las operaciones
		//incluir, modificar y eliminar
		//solo cambia para buscar 
	}
	
	function modificar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->fecvacuna)){
			try {
					$r = $co->prepare("Update pacientesvac set 
					    dosis_vacuna = :dosisvacuna,
					     id_paciente = :cedulacliente,
					     id_vacuna = :cedularepresentante
						where
						fecha_vacunacion = :fecvacuna
						");
						
			        $r->bindParam(':dosisvacuna',$this->dosisvacuna);
					$r->bindParam(':fecvacuna',$this->fecvacuna);	
					$r->bindParam(':cedulacliente',$this->cedulacliente);
					$r->bindParam(':cedularepresentante',$this->cedularepresentante);

					
					
					$r->execute();
						
						
						
						return "Registro Modificado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "fecha no registrada";
		}
		
	}
	
	function eliminar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->fecvacuna)){
			try {
					$r = $co->prepare("Delete from pacientesvac
						where
						fecha_vacunacion = :fecvacuna
						");
					$r->bindParam(':fecvacuna',$this->fecvacuna);	
					
					$r->execute();
					
						return "Registro Eliminado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "fecha no registrada";
		}
	}
	
	
	function consultar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from pacientesvac");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='coloca(this);'>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fecha_vacunacion'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['dosis_vacuna'];
						$respuesta = $respuesta."</td>";
					    $respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['id_paciente'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['id_vacuna'];
						$respuesta = $respuesta."</td>";	
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
	
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	private function existe($fecvacuna){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			//AQUI COMENZAREMOS A HACER USO DE LO QUE SON LAS CONSULTAS PARAMETRIZABLES
			//PARA ELLO UTILIZAREMOS LA INSTRUCCIÓN Y AÑADIREMOS LOS PASOS PREPARE
			//Y EXECUTE PARA REGISTRAR O CONSULTAR EN LA BASE DE DATOS
			
			//ANTERIORMENTE ERA query(consuta sql)
			//$resultado = $co->query("Select * from paciente where fecvacuna_paciente='$fecvacuna'");
			
			//AHORA QUEDA
			$resultado = $co->prepare("Select * from pacientesvac where fecha_vacunacion=:fecvacuna");
			//COMO VEN SE CAMBIO A $fecvacuna QUE ES UNA VARIABLE QUE SE USA POR :fecvacuna
			//QUE ES UN VALOR NO DECLARADO, POR LO QUE EL SIGUIETE PASO SERA 
			//INDICARLE A PHP QUIEN ES ESE :fecvacuna Y PARA ELLO USAREMOS LA INSTRUCCION
			//bindParam QUE COLOCA UN VALOR EN :fecvacuna Y EVITA QUE SE INCLUYAN 
			//INSTRUCCIONES QUE SE PUEDEN USAR EN MYSQL INJECT
			$resultado->bindParam(':fecvacuna',$fecvacuna);
			//YA SE TIENE EL VALOR DE :fecvacuna
			//EL SIGUIENTE PASO ES EJUTAR LA CONSULTA
			
			$resultado->execute();
			
			//LO DEMAS QUEDA IGUAL
			$fila = $resultado->fetchAll(PDO::FETCH_BOTH);
			if($fila){

				return true;
			    
			}
			else{
				
				return false;;
			}
			
		}catch(Exception $e){
			return false;
		}
	}

   

	
	function listadoderepresentantes(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from vacunas");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='colocarepresentante(this);'>";
						$respuesta = $respuesta."<td style='display:none'>";
							$respuesta = $respuesta.$r['id_vacunas'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['codigo_vacuna'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre_vacuna'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['vacuna_disponible'];
						$respuesta = $respuesta."</td>";
						
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}

	function listadodeclientes(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from pacientes");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='colocacliente(this);'>";
						$respuesta = $respuesta."<td style='display:none'>";
						    $respuesta = $respuesta.$r['id_paciente'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_paciente'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fechadenacimiento'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['sexo'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['peso_nacimiento_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['estatura_nacimiento_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['desarrollo_psicomotor_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_pers_no_patologicos'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_heredo_familiar'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_prenatales_pac'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['antec_postnatales_pac'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	
	
}


?>