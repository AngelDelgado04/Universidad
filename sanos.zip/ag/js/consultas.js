
$(document).ready(function(){


//Seccion para mostrar lo enviado en el modal mensaje//

//Función que verifica que exista algo dentro de un div
//oculto y lo muestra por el modal
if($.trim($("#mensajes").text()) != ""){
	muestraMensaje($("#mensajes").html());
}
//Fin de seccion de mostrar envio en modal mensaje//	
	
//VALIDACION DE DATOS
	$("#examenfis").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#examenfis").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,30}$/,
		$(this),$("#sexamenfis"),"Solo letras  entre 3 y 30 caracteres");
	});

	$("#comppac").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#comppac").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,30}$/,
		$(this),$("#scomppac"),"Solo letras  entre 3 y 30 caracteres");
	});

	$("#alimpac").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#alimpac").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,30}$/,
		$(this),$("#salimpac"),"Solo letras  entre 3 y 30 caracteres");
	});

	$("#pesocon").on("keypress",function(e){
		validarkeypress(/^[0-9KG\b]*$/,e);
	});
	
	$("#pesocon").on("keyup",function(){
		validarkeyup(/^[0-9]{1,2}[KG]{2}$/,
		$(this),$("#spesocon"),"Solo letras  entre 3 y 30 caracteres");
	});

	$("#estcon").on("keypress",function(e){
		validarkeypress(/^[0-9CM\b]*$/,e);
	});
	
	$("#estcon").on("keyup",function(){
		validarkeyup(/^[0-9]{2,3}[CM]{2}$/,
		$(this),$("#sestcon"),"Solo letras  entre 3 y 30 caracteres");
	});

	$("#feccon").on("keyup",function(){
		validarkeyup(/^(?:(?:1[6-9]|[2-9]\d)?\d{2})(?:(?:(\/|-|\.)(?:0?[13578]|1[02])\1(?:31))|(?:(\/|-|\.)(?:0?[13-9]|1[0-2])\2(?:29|30)))$|^(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)0?2\3(?:29)$|^(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:0?[1-9]|1\d|2[0-8])$/,
		$(this),$("#sfeccon"),"Ingrese una fecha valida");
	});

	
//FIN DE VALIDACION DE DATOS



//CONTROL DE BOTONES

$("#incluir").on("click",function(){
	if(validarenvio()){
		$("#accion").val("incluir");	
		$("#f").submit();
	}
});
$("#modificar").on("click",function(){
	if(validarenvio()){
		$("#accion").val("modificar");	
		$("#f").submit();
	}
});
$("#eliminar").on("click",function(){
	if(validarkeyup(/^(?:(?:1[6-9]|[2-9]\d)?\d{2})(?:(?:(\/|-|\.)(?:0?[13578]|1[02])\1(?:31))|(?:(\/|-|\.)(?:0?[13-9]|1[0-2])\2(?:29|30)))$|^(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)0?2\3(?:29)$|^(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:0?[1-9]|1\d|2[0-8])$/,
		$("#feccon"),$("#sfeccon"),"Ingrese una fecha valida")==0){
		muestraMensaje("Fecha de Consulta <br/>Ingrese una fecha valida");	
	}
	
	else{	
		$("#accion").val("eliminar");	
		$("#f").submit();
	}
	
});
//FIN DE CONTROL DE BOTONES	


	
	
});

//Validación de todos los campos antes del envio
function validarenvio(){
	if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,30}$/,
		$("#examenfis"),$("#sexamenfis"),"Solo letras  entre 3 y 30 caracteres")==0){
		muestraMensaje("examenfis <br/>Solo letras  entre 3 y 30 caracteres");
		return false;
	}
	else if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,30}$/,
		$("#comppac"),$("#scomppac"),"Solo letras  entre 3 y 30 caracteres")==0){
		muestraMensaje("comppac <br/>Solo letras  entre 3 y 30 caracteres");
		return false;
	}
	else if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,30}$/,
		$("#alimpac"),$("#salimpac"),"Solo letras  entre 3 y 30 caracteres")==0){
		muestraMensaje("alimpac <br/>Solo letras  entre 3 y 30 caracteres");
		return false;
	}
	else if(validarkeyup(/^[0-9]{1,2}[KG]{2}$/,
		$("#pesocon"),$("#spesocon"),"Solo letras  entre 3 y 30 caracteres")==0){
		muestraMensaje("pesocon <br/>Solo letras  entre 3 y 30 caracteres");
		return false;
	}
	else if(validarkeyup(/^[0-9]{2,3}[CM]{2}$/,
		$("#estcon"),$("#sestcon"),"Solo letras  entre 3 y 30 caracteres")==0){
		muestraMensaje("estcon <br/>Solo letras  entre 3 y 30 caracteres");
		return false;
	}
	else if(validarkeyup(/^(?:(?:1[6-9]|[2-9]\d)?\d{2})(?:(?:(\/|-|\.)(?:0?[13578]|1[02])\1(?:31))|(?:(\/|-|\.)(?:0?[13-9]|1[0-2])\2(?:29|30)))$|^(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)0?2\3(?:29)$|^(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:0?[1-9]|1\d|2[0-8])$/,
		$("#feccon"),$("#sfeccon"),"Ingrese una fecha valida")==0){
		muestraMensaje("Fecha de Consulta <br/>Ingrese una fecha valida");
		return false;	
	}
	else {
		var f1 = new Date(2021,01,01);
		var f2 = new Date($("#feccon").val());
		
		if(f2 < f1){
			muestraMensaje("Fecha de Consulta <br/>La fecha debe ser mayor o igual a 01/01/2021");
			return false;
		}
		
	}
	
	return true;
}


//Funcion que muestra el modal con un mensaje
function muestraMensaje(mensaje){
	
	$("#contenidodemodal").html(mensaje);
			$("#mostrarmodal").modal("show");
			setTimeout(function() {
					$("#mostrarmodal").modal("hide");
			},5000);
}


//Función para validar por Keypress
function validarkeypress(er,e){
	
	key = e.keyCode;
	
	
    tecla = String.fromCharCode(key);
	
	
    a = er.test(tecla);
	
    if(!a){
	
		e.preventDefault();
    }
	
    
}
//Función para validar por keyup
function validarkeyup(er,etiqueta,etiquetamensaje,
mensaje){
	a = er.test(etiqueta.val());
	if(a){
		etiquetamensaje.text("");
		return 1;
	}
	else{
		etiquetamensaje.text(mensaje);
		return 0;
	}
}

function coloca(linea){
	$("#nombre").val($(linea).find("td:eq(0)").text());
	$("#cedula").val($(linea).find("td:eq(1)").text());
	$("#telefono").val($(linea).find("td:eq(2)").text());
	$("#direccion").val($(linea).find("td:eq(3)").text());
}
