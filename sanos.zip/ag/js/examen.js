
$(document).ready(function(){

//Seccion para mostrar lo enviado en el modal mensaje//

//Función que verifica que exista algo dentro de un div
//oculto y lo muestra por el modal
if($.trim($("#mensajes").text()) != ""){
	muestraMensaje($("#mensajes").html());
}
//Fin de seccion de mostrar envio en modal mensaje//	
	
//VALIDACION DE DATOS	
	
	
	$("#nomexamen").on("keypress",function(e){
		validarkeypress(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]*$/,e);
	});
	
	$("#nomexamen").on("keyup",function(){
		validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}$/,
		$(this),$("#snomexamen"),"Solo letras entre 3 y 15 caracteres");
	});
	

	$("#nexamen").on("keypress",function(e){
		validarkeypress(/^[0-9\b]*$/,e);
	});
	
	$("#nexamen").on("keyup",function(){
		validarkeyup(/^[0-9]{3,4}$/,$(this),
		$("#snexamen"),"Solo numeros, ejemplo 0001");
	});
	
	
//FIN DE VALIDACION DE DATOS

//CONTROL DE BOTONES

$("#incluir").on("click",function(){
	if(validarenvio()){
		$("#accion").val("incluir");	
		$("#f").submit();
	}
});
$("#modificar").on("click",function(){
	if(validarenvio()){
		$("#accion").val("modificar");	
		$("#f").submit();
	}
});
$("#eliminar").on("click",function(){

	if(validarkeyup(/^[0-9]{3,4}$/,$("#nexamen"),
		$("#snexamen"),"Solo numeros ejemplo 0001")==0){
		muestraMensaje("Numero de Examen <br/>Ejemplo 0001");
		
	}	
		
	
	else{	
		$("#accion").val("eliminar");	
		$("#f").submit();
	}
	
});
//FIN DE CONTROL DE BOTONES	


	
	
});

//Validación de todos los campos antes del envio
function validarenvio(){
		
	if(validarkeyup(/^[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{3,15}$/,
		$("#nomexamen"),$("#snomexamen"),"Solo letras entre 3 y 15 caracteres")==0){
		muestraMensaje("El nombre del examen debe contener entre 3 y 15 letras");
		return false;
	}
	
	else if(validarkeyup(/^[0-9]{3,4}$/,$("#nexamen"),
		$("#snexamen"),"Solo numeros ejemplo 0001")==0){
		muestraMensaje("Numero de examen <br/>Ejemplo 0001");
		return false;
	}
	
	return true;
}


//Funcion que muestra el modal con un mensaje
function muestraMensaje(mensaje){
	$("#contenidodemodal").html(mensaje);
			$("#mostrarmodal").modal("show");
			setTimeout(function() {
					$("#mostrarmodal").modal("hide");
			},4000);
}


//Función para validar por Keypress
function validarkeypress(er,e){
	
	key = e.keyCode;
	
	
    tecla = String.fromCharCode(key);
	
	
    a = er.test(tecla);
	
    if(!a){
	
		e.preventDefault();
    }
	
    
}
//Función para validar por keyup
function validarkeyup(er,etiqueta,etiquetamensaje,
mensaje){
	a = er.test(etiqueta.val());
	if(a){
		etiquetamensaje.text("");
		return 1;
	}
	else{
		etiquetamensaje.text(mensaje);
		return 0;
	}
}

function coloca(linea){
	$("#nexamen").val($(linea).find("td:eq(0)").text());
	$("#nomexamen").val($(linea).find("td:eq(1)").text());
	$("#disponibilidad").val($(linea).find("td:eq(2)").text());

}
