<link rel="stylesheet" href="css/styles.css">

<nav class="navbar navbar-expand-lg col py-0">
   
    <button class="navbar-toggler" type="button" data-toggle="collapse"  
    data-target="#navbarNavDropdown" 
    aria-controls="navbarNavDropdown" aria-expanded="false" 
    aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button> 
<img src="img/principal.jpg" alt="" style="width:50px;">

<div class="collapse navbar-collapse" id="navbarNavDropdown">

      <?php  

      if(empty($_SESSION)){
          session_start();
      }
      
      if(isset($_SESSION['nivel'])){
       $nivel = $_SESSION['nivel'];
   }   
   else{
    $nivel = "";
}
?>  

<ul class="navbar-nav ml-auto">
   <?php
   if($nivel !== ""){
      ?>

      <?php     
  }
  ?>

</ul>
<?php
if($nivel == "admin" or $nivel == "user"){
?>
<a href="?pagina=salida" class="text-dark text-decoration-none"><img src="img/perfil.png" alt="" width="32" height="32" class="rounded-circle me-2"> <strong>Cerrar Sesión</strong></a>
<?php  
}
?>
</div> 

</nav>

<div class="d-flex">
	<div class="verticalLine">
     <div id="sidebar-container" class="bg-light">
        

        <div class="logo">
            <h3 class="text-dark font-weight bold">Amb</h3>
        </div>

        <hr>

        <div class="menu">
     <!--    <a href="?pagina=medicos" class="d-block p-3 text-dark"><img src="img/medico.png" alt="" width="32" height="32" class="rounded-circle me-2"> Medico</a>

            <hr> 
             <a href="?pagina=representantes" class="d-block p-3 text-dark"><img src="img/representantes.png" alt="" width="32" height="32" class="rounded-circle me-2"> Representantes</a>

            <hr>


            <a href="?pagina=pacientes" class="d-block p-3 text-dark"><img src="img/pacientes.png" alt="" width="32" height="32" class="rounded-circle me-2"> Pacientes</a>

            <hr>-->

            <a  href="?pagina=vacunaspacientes" class="d-block p-3 text-dark"><img src="img/vapac.png" alt="" width="32" height="32" class="rounded-circle me-2"> Vacunas del paciente</a>

            <hr>

            <a href="?pagina=consultas" class="d-block p-3 text-dark"><img src="img/consultas.png" alt="" width="32" height="32" class="rounded-circle me-2"> Consultas</a>

            <hr>

            <div class="dropdown">

                <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="d-block p-3 text-dark"><img src="img/carpeta.png" alt="" width="18" height="18" class="rounded-circle me-2"> Recetas consultas
                </button>

                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="?pagina=medicinacon"><img src="img/medicina.png" alt="" width="32" height="32" class="rounded-circle me-2"> Medicinas</a>
                    <a class="dropdown-item" href="?pagina=examencon"><img src="img/examenes.png" alt="" width="32" height="32" class="rounded-circle me-2"> Examenes</a>
                </div>
            </div>

            <hr>

            <div class="dropdown">

                <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="d-block p-3 text-dark"><img src="img/carpeta.png" alt="" width="32" height="32" class="rounded-circle me-2"> Catalogo
                </button>

                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="?pagina=medicinas"><img src="img/medicina.png" alt="" width="32" height="32" class="rounded-circle me-2"> Medicinas</a>
                    <a class="dropdown-item" href="?pagina=examen"><img src="img/examenes.png" alt="" width="32" height="32" class="rounded-circle me-2"> Examenes</a>
                    <a class="dropdown-item" href="?pagina=vacunas"><img src="img/vacuna.png" alt="" width="32" height="32" class="rounded-circle me-2"> Vacunas</a>
                </div>
            </div>
        </div>     
    </div>
</div>

