<?php
//llamda al archivo que contiene la clase
//datos, en ella posteriormente se colcora el codigo
//para enlazar a su base de datos
require_once('modelo/datos.php');

//declaracion de la clase usuarios que hereda de la clase datos
//la herencia se declara con la palabra extends y no es mas 
//que decirle a esta clase que puede usar los mismos metodos
//que estan en la clase de dodne hereda (La padre) como sir fueran de el

class medicos extends datos{
	//el primer paso dentro de la clase
	//sera declarar los atributos (variables) que describen la clase
	//para nostros no es mas que colcoar los inputs (controles) de
	//la vista como variables aca
	//cada atributo debe ser privado, es decir, ser visible solo dentro de la
	//misma clase, la forma de colcoarlo privado es usando la palabra private
	
	private $cedula; //recuerden que en php, las variables no tienen tipo predefinido
	private $nombres;
	private $apellidos;
	private $fecingreso;
	private $correo;
	private $horario;
	
	
	//Ok ya tenemos los atributos, pero como son privados no podemos acceder a ellos desde fueran
	//por lo que debemos colcoar metodos (funciones) que me permitan leer (get) y colocar (set)
	//valores en ello, esto es  muy mal llamado geters y seters por si alguien se los pregunta
	
	function set_cedula($valor){
		$this->cedula = $valor; //fijencen como se accede a los elementos dentro de una clase
		//this que singnifica esto es decir esta clase luego -> simbolo que indica que apunte
		//a un elemento de this, es decir esta clase
		//luego el razon del elemento sin el $
	}
	//lo mismo que se hizo para cedula se hace para usuario y clave
	
	function set_nombres($valor){
		$this->nombres = $valor;
	}

	function set_apellidos($valor){
		$this->apellidos = $valor;
	}
	
	function set_fecingreso($valor){
		$this->fecingreso = $valor;
	}
	
	function set_correo($valor){
		$this->correo = $valor;
	}

	function set_horario($valor){
		$this->horario = $valor;
	}
	
	//Lo siguiente que demos hacer es crear los metodos para incluir, consultar y eliminar
	
	function incluir(){
		//Ok ya tenemos la base de datos y la funcion conecta dentro de la clase
		//datos, ahora debemos ejecutar las operaciones para realizar las consultas 
		
		//Lo primero que debemos hacer es consultar por el campo clave
		//en este caso la cedula, para ello se creo la funcion existe
		//que retorna true en caso de exitir el registro
		
		if(!$this->existe($this->cedula)){
			//si estamos aca es porque la cedula no existe es decir se puede incluir
			//los pasos a seguir son
			//1 Se llama a la funcion conecta 
			$co = $this->conecta();
			$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//2 Se ejecuta el sql
			try {
					$r = $co->prepare("Insert into medicos(
						nombre_med,
						apellido_med,
						cedula_med,
						fecha_ingreso_doctor,
						correo_med,
						horario_trabajo_doctor
						)
						Values(
						:nombres,
						:apellidos,
						:cedula,
						:fecingreso,
						:correo,
						:horario
						)");
						
					$r->bindParam(':nombres',$this->nombres);
					$r->bindParam(':apellidos',$this->apellidos);	
					$r->bindParam(':cedula',$this->cedula);	
					$r->bindParam(':fecingreso',$this->fecingreso);
					$r->bindParam(':correo',$this->correo);	
					$r->bindParam(':horario',$this->horario);
					
					$r->execute();
					
						return "Registro incluido";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "Ya existe el cedula que desea ingresar";
		}
		
		//Listo eso es todo y es igual para el resto de las operaciones
		//incluir, modificar y eliminar
		//solo cambia para buscar 
	}
	
	function modificar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->cedula)){
			try {
					$r = $co->prepare("Update medicos set 
					    nombre_med = :nombres,
					    apellido_med = :apellidos,
						fecha_ingreso_doctor = :fecingreso,
						correo_med = :correo,
						horario_trabajo_doctor = :horario
						where
						cedula_med = :cedula
						");
						
					$r->bindParam(':nombres',$this->nombres);
					$r->bindParam(':apellidos',$this->apellidos);	
					$r->bindParam(':fecingreso',$this->fecingreso);	
					$r->bindParam(':correo',$this->correo);	
					$r->bindParam(':horario',$this->horario);	
					$r->bindParam(':cedula',$this->cedula);	
					
					$r->execute();
						
						
						
						return "Registro Modificado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "cedula no registrada";
		}
		
	}
	
	function eliminar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		if($this->existe($this->cedula)){
			try {
					$r = $co->prepare("Delete from medicos 
						where
						cedula_med = :cedula
						");
					$r->bindParam(':cedula',$this->cedula);	
					
					$r->execute();
					
						return "Registro Eliminado";
			} catch(Exception $e) {
				return $e->getMessage();
			}
		}
		else{
			return "cedula no registrada";
		}
	}
	
	
	function consultar(){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			
			$resultado = $co->query("Select * from medicos");
			
			if($resultado){
				
				$respuesta = '';
				foreach($resultado as $r){
					$respuesta = $respuesta."<tr style='cursor:pointer' onclick='coloca(this);'>";
					    $respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['cedula_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['nombre_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['apellido_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['fecha_ingreso_doctor'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
							$respuesta = $respuesta.$r['correo_med'];
						$respuesta = $respuesta."</td>";
						$respuesta = $respuesta."<td>";
						    $respuesta = $respuesta.$r['horario_trabajo_doctor'];
						$respuesta = $respuesta."</td>";
					$respuesta = $respuesta."</tr>";
				}
				return $respuesta;
			    
			}
			else{
				return '';
			}
			
		}catch(Exception $e){
			return $e->getMessage();
		}
		
	}
	
	
	private function existe($cedula){
		$co = $this->conecta();
		$co->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		try{
			//AQUI COMENZAREMOS A HACER USO DE LO QUE SON LAS CONSULTAS PARAMETRIZABLES
			//PARA ELLO UTILIZAREMOS LA INSTRUCCIÓN Y AÑADIREMOS LOS PASOS PREPARE
			//Y EXECUTE PARA REGISTRAR O CONSULTAR EN LA BASE DE DATOS
			
			//ANTERIORMENTE ERA query(consuta sql)
			//$resultado = $co->query("Select * from doctor where cedula_med='$cedula'");
			
			//AHORA QUEDA
			$resultado = $co->prepare("Select * from medicos where cedula_med=:cedula");
			//COMO VEN SE CAMBIO A $cedula QUE ES UNA VARIABLE QUE SE USA POR :cedula
			//QUE ES UN VALOR NO DECLARADO, POR LO QUE EL SIGUIETE PASO SERA 
			//INDICARLE A PHP QUIEN ES ESE :cedula Y PARA ELLO USAREMOS LA INSTRUCCION
			//bindParam QUE COLOCA UN VALOR EN :cedula Y EVITA QUE SE INCLUYAN 
			//INSTRUCCIONES QUE SE PUEDEN USAR EN MYSQL INJECT
			$resultado->bindParam(':cedula',$cedula);
			//YA SE TIENE EL VALOR DE :cedula
			//EL SIGUIENTE PASO ES EJUTAR LA CONSULTA
			
			$resultado->execute();
			
			//LO DEMAS QUEDA IGUAL
			$fila = $resultado->fetchAll(PDO::FETCH_BOTH);
			if($fila){

				return true;
			    
			}
			else{
				
				return false;;
			}
			
		}catch(Exception $e){
			return false;
		}
	}


	
	
	
}
?>