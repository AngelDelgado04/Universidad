<?php
  
//llamada al archivo que contiene la clase
//usuarios, en ella estara el codigo que me //permitirá
//guardar, consultar y modificar dentro de mi base //de datos


//lo primero que se debe hacer es verificar al //igual que en la vista que exista el archivo
if (!is_file("modelo/".$pagina.".php")){
  //alli pregunte que si no es archivo se niega //con !
  //si no existe envio mensaje y me salgo
  echo "Falta definir la clase ".$pagina;
  exit;
}  
require_once("modelo/".$pagina.".php");  
  if(is_file("vista/".$pagina.".php")){
    
    
    
    
    $o = new pacientes(); 
    
    
    $consultarepresentantes = $o->listadoderepresentantes();

    if(!empty($_POST)){
      
      //como ya sabemos si estamos aca es //porque se recibio alguna informacion
      //de la vista, por lo que lo primero que //debemos hacer ahora que tenemos una 
      //clase es guardar esos valores en ella //con los metodos set
      $accion = $_POST['accion'];
      $o->set_cedula($_POST['cedula']);
      $o->set_nombre($_POST['nombre']);
      $o->set_fechadenacimiento($_POST['fechadenacimiento']);
       if(!empty($_POST['sexo'])){
      $o->set_sexo($_POST['sexo']);
        }
      $o->set_pesonacimiento($_POST['pesonacimiento']);
      $o->set_estnacimiento($_POST['estnacimiento']);
      $o->set_desarrollopsi($_POST['desarrollopsi']);
      $o->set_antecnopato($_POST['antecnopato']);
      $o->set_antecheredo($_POST['antecheredo']);
      $o->set_antecpre($_POST['antecpre']);
      $o->set_antecpost($_POST['antecpost']);

        
      if($accion=='incluir'){
      $mensaje =  $o->incluir();
      }
      elseif($accion=='modificar'){
      $mensaje =  $o->modificar();
      
      }
      elseif($accion=='eliminar'){
      $mensaje =  $o->eliminar();
      
      }
    }
    $consulta = $o->consultar();

    
    require_once("vista/".$pagina.".php"); 
  }
  else{
    echo "pagina en construccion";
  }
?>
