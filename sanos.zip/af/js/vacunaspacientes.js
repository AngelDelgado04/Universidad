
$(document).ready(function(){
//para mostrar en modal mensajes del servidor	
if($.trim($("#mensajes").text()) != ""){
	muestraMensaje($("#mensajes").html());
}
//Fin de seccion de mostrar envio en modal mensaje//	

//VALIDACION DE DATOS	
	
	$("#fecvacuna").on("keyup",function(){
		validarkeyup(/^(?:(?:1[6-9]|[2-9]\d)?\d{2})(?:(?:(\/|-|\.)(?:0?[13578]|1[02])\1(?:31))|(?:(\/|-|\.)(?:0?[13-9]|1[0-2])\2(?:29|30)))$|^(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)0?2\3(?:29)$|^(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:0?[1-9]|1\d|2[0-8])$/,
		$(this),$("#sfecvacuna"),"Ingrese una fecha valida");
	});

//FIN DE VALIDACION DE DATOS


//CONTROL DE BOTONES

$("#incluir").on("click",function(){
	if(validarenvio()){
		$("#accion").val("incluir");	
		$("#f").submit();
	}
});
$("#modificar").on("click",function(){
	if(validarenvio()){
		$("#accion").val("modificar");	
		$("#f").submit();
	}
});
$("#eliminar").on("click",function(){
	if(validarkeyup(/^(?:(?:1[6-9]|[2-9]\d)?\d{2})(?:(?:(\/|-|\.)(?:0?[13578]|1[02])\1(?:31))|(?:(\/|-|\.)(?:0?[13-9]|1[0-2])\2(?:29|30)))$|^(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)0?2\3(?:29)$|^(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:0?[1-9]|1\d|2[0-8])$/,
		$("#fecvacuna"),$("#sfecvacuna"),"Ingrese una fecha valida")==0){
		muestraMensaje("Fecha de Nacimiento <br/>Ingrese una fecha valida");	
		
	}
	else{	
		$("#accion").val("eliminar");	
		$("#f").submit();
	}
	
});
//FIN DE CONTROL DE BOTONES	

//Validación de todos los campos antes del envio
function validarenvio(){
	 if(validarkeyup(/^(?:(?:1[6-9]|[2-9]\d)?\d{2})(?:(?:(\/|-|\.)(?:0?[13578]|1[02])\1(?:31))|(?:(\/|-|\.)(?:0?[13-9]|1[0-2])\2(?:29|30)))$|^(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(\/|-|\.)0?2\3(?:29)$|^(?:(?:1[6-9]|[2-9]\d)?\d{2})(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:0?[1-9]|1\d|2[0-8])$/,
		$("#fecvacuna"),$("#sfecvacuna"),"Ingrese una fecha valida")==0){
		muestraMensaje("Fecha de Nacimiento <br/>Ingrese una fecha valida");
		return false;	
	}
	else {
		var f1 = new Date(2010,01,01);
		var f2 = new Date($("#fecvacuna").val());
		
		if(f2 < f1){
			muestraMensaje("Fecha de Nacimiento <br/>La fecha debe ser mayor o igual a 01/01/2010");
			return false;
		}
		
	}

	return true;
}


	
//boton para levantar modal de representantes
$("#modalderepresentantes").on("click",function(){
	$("#modalrepresentantes").modal("show");
});



//evento keyup de input cedularepresentante	
$("#cedularepresentante").on("keyup",function(){
	var cedula = $(this).val();
	var encontro = false;
	$("#listadoderepresentantes tr").each(function(){
		if(cedula == $(this).find("td:eq(1)").text()){
			colocarepresentante($(this));
			encontro = true;
		} 
	});
	if(!encontro){
		$("#datosdelrepresentante").html("");
	}
});	


	
	
});


//function para buscar si existe el representante 
function existerepresentante(){
	var codigo = $("#cedularepresentante").val();
	var existe = false;
	$("#listadoderepresentantes tr").each(function(){
		if(codigo == $(this).find("td:eq(1)").text()){
			existe = true;
		}
	});
	
	return existe;
	
}
//fin de funcion existerepresentante








//funcion para colocar datos del representante en pantalla
function colocarepresentante(linea){
	$("#cedularepresentante").val($(linea).find("td:eq(1)").text());
	$("#idrepresentante").val($(linea).find("td:eq(0)").text());
	$("#datosdelrepresentante").html($(linea).find("td:eq(2)").text()+
	"  "+$(linea).find("td:eq(3)").text()+"  "+
	$(linea).find("td:eq(4)").text()+"  "+
	$(linea).find("td:eq(5)").text()+"  "+
	$(linea).find("td:eq(7)").text());
}

//fin de colocar datos del representante

//boton para levantar modal de clientes
$("#modaldeclientes").on("click",function(){
	$("#modalclientes").modal("show");
});

//evento keyup de input cedulacliente	
$("#cedulacliente").on("keyup",function(){
	var cedula = $(this).val();
	var encontro = false;
	$("#listadodeclientes tr").each(function(){
		if(cedula == $(this).find("td:eq(1)").text()){
			colocacliente($(this));
			encontro = true;
		} 
	});
	if(!encontro){
		$("#datosdelcliente").html("");
	}
});	
//function para buscar si existe el cliente 
function existecliente(){
	var cedula = $("#cedulacliente").val();
	var existe = false;
	$("#listadodeclientes tr").each(function(){
		if(cedula == $(this).find("td:eq(1)").text()){
			existe = true;
		}
	});
	
	return existe;
	
}
//fin de funcion existecliente

//funcion para colocar datos del cliente en pantalla
function colocacliente(linea){
	$("#cedulacliente").val($(linea).find("td:eq(1)").text());
	$("#idcliente").val($(linea).find("td:eq(0)").text());
	$("#datosdelcliente").html($(linea).find("td:eq(2)").text()+
	"  "+$(linea).find("td:eq(3)").text()+"  "+
	$(linea).find("td:eq(4)").text());
}

//fin de colocar datos del cliente




//Funcion que muestra el modal con un mensaje
function muestraMensaje(mensaje){
	$("#contenidodemodal").html(mensaje);
			$("#mostrarmodal").modal("show");
			setTimeout(function() {
					$("#mostrarmodal").modal("hide");
			},5000);
}


//Función para validar por Keypress
function validarkeypress(er,e){
	
	key = e.keyCode;
	
	
    tecla = String.fromCharCode(key);
	
	
    a = er.test(tecla);
	
    if(!a){
	
		e.preventDefault();
    }
	
    
}
//Función para validar por keyup
function validarkeyup(er,etiqueta,etiquetamensaje,
mensaje){
	a = er.test(etiqueta.val());
	if(a){
		etiquetamensaje.text("");
		return 1;
	}
	else{
		etiquetamensaje.text(mensaje);
		return 0;
	}
}




//funcion para limpiar la pantalla
function limpia(){

	$("#cedularepresentante").val('');
	$("#idrepresentante").val('');
	$("#datosdelrepresentante").html('');

	$("#cedulacliente").val('');
	$("#idcliente").val('');

	$("#datosdelcliente").html('');

}

function coloca(linea){
	$("#fecvacuna").val($(linea).find("td:eq(0)").text());
	
	$("#dosisvacuna").val($(linea).find("td:eq(1)").text());
}

