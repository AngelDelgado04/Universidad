<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<div class="card card-container">
            <div class="card-header">   	
				<div class="container text-center h2 text-black-50">
					Registro Consultas
				</div>
			</div>
        <div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
    <form method="post" action="" id="f">
    <input type="text" name="accion" id="accion" style="display:none"/>

	<div class="row">
		<div class="col">
		<hr/>
		</div>
	</div>	
					<div class="row">
						<div class="col">
							<label for="cmedico">Cedula del Medico</label>
							<input class="form-control" type="text" id="cmedico" name="cmedico"/>
							<span id="scmedico"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<label for="horincon">Hora de inicio de la consulta</label>
							<input class="form-control" type="time" id="horincon" name="horincon"  
							required  
							title="Horario consulta"/>
							<span id="shorincon"></span>
						</div>

						<div class="col">
							<label for="horfincon">Hora final de la consulta</label>
							<input class="form-control" type="time" id="horfincon" name="horfincon"  
							required  
							title="Horario final de la consulta"/>
							<span id="shorfincon"></span>
						</div>

						<div class="col">
							<label for="feccon">Fecha de la consulta</label>
							<input class="form-control" type="date" id="feccon" name="feccon"  
							value="<?php 
						    $f = date('Y-m-d');
						    $f1 = strtotime ('-1 year' , strtotime($f)); 
					        $f1 = date ('Y-m-d',$f1);
					        echo $f1; ?>"
		                    />
							<span id="sfeccon"></span>
						</div>

					</div>

					<div class="row">
						<div class="col">
							<label for="pesocon">Peso del paciente</label>
							<input class="form-control" type="text" id="pesocon" name="pesocon"/>
							<span id="spesocon"></span>
						</div>
						
						<div class="col">
							<label for="estcon">Estatura del paciente</label>
							<input class="form-control" type="text" id="estcon" name="estcon"/>
							<span id="sestcon"></span>
						</div>

						<div class="col">
							<label for="fecingcon">Fecha de ingreso de la consulta</label>
							<input class="form-control" type="date" id="fecingcon" name="fecingcon"
							value="<?php 
						    $f = date('Y-m-d');
						    $f1 = strtotime ('-1 year' , strtotime($f)); 
					        $f1 = date ('Y-m-d',$f1);
					        echo $f1; ?>"
		                    />
							<span id="sfecingcon"></span>
						</div>

						<div class="col">
							<label for="nhmedico">Cedula del Paciente</label>
							<input class="form-control" type="text" id="nhmedico" name="nhmedico"/>
							<span id="snhmedico"></span>
						</div>
					</div>

					<div class="row">

						<div class="col">
							<label for="hordorm">Horas que duerme el paciente</label>
							<input class="form-control" type="text" id="fhordorm" name="hordorm" 
							pattern="[0-9]{2}[A-Za-z]{3}" 
							required
							maxlength="5" 
							minlength="3" 
							title="Horas que duerme el paciente Ej. 2hr, 30min"/>
							<span id="shordorm"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<label for="examenfis">Examen físico del paciente</label>
							<input class="form-control" type="text" id="examenfis" name="examenfis"/>
							<span id="sexamenfis"></span>
						</div>

						<div class="col">
							<label for="comppac">Complicaciones del paciente</label>
							<input class="form-control" type="text" id="comppac" name="comppac"/>
							<span id="scomppac"></span>
						</div>

						<div class="col">
							<label for="alimpac">Frecuencia alimentaria del paciente</label>
							<input class="form-control" type="text" id="alimpac" name="alimpac"/>
							<span id="salimpac"></span>
						</div>	
					</div>

					<div class="row">
						<div class="col">
							<hr/>
						</div>
					</div>
			

				<div class="card-footer text-muted"> <!-- inicio de los botones -->
					<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
			                <button type="button" class="btn btn-primary" id="consultar" 
			                data-toggle="modal" data-target="#modal1" name="consultar">CONSULTAR</button>
		                </div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
			</div><!-- fin del container que engloba todo -->
			</form>	

		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->

<script type="text/javascript" src="js/consultas.js"></script>

</body>
</html>