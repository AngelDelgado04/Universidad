<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<div class="card card-container">
            <div class="card-header">   	
				<div class="container text-center h2 text-black-50">
					Registro Consultas
				</div>
			</div>
        <div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
    <form method="post" action="" id="f">
    <input type="text" name="accion" id="accion" style="display:none"/>

	<div class="row">
		<div class="col">
		<hr/>
		</div>
	</div>	
					<div class="row">
						<div class="col">
							<label for="nconsulta">Numero de control de consulta</label>
							<input class="form-control" type="text" id="nconsulta" name="nconsulta" 
							pattern="[0-9]{5,7}"
							required 
							maxlength="7" 
							minlength="5" 
							title="Solo numeros entre 5 y 7"/>
							<span id="snconsulta"></span>
						</div>

						<div class="col">
							<label for="nmedico">Número de Medico</label>
							<input class="form-control" type="text" id="nmedico" name="nmedico" 
							pattern="[A-Za-z]{2}[-]{1}[A-Za-z]{2}[-]{1}[0-9]{5}" 
							required 
							maxlength="11" 
							minlength="8" 
							title="El formato debe ser XX-YY-ZZZZZ"/>
							<span id="snmedico"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<label for="horincon">Hora de inicio de la consulta</label>
							<input class="form-control" type="time" id="horincon" name="horincon"  
							required  
							title="Horario consulta"/>
							<span id="shorincon"></span>
						</div>

						<div class="col">
							<label for="horfincon">Hora final de la consulta</label>
							<input class="form-control" type="time" id="horfincon" name="horfincon"  
							required  
							title="Horario final de la consulta"/>
							<span id="shorfincon"></span>
						</div>

						<div class="col">
							<label for="feccon">Fecha de la consulta</label>
							<input class="form-control" type="date" id="feccon" name="feccon"  
							required  
							title="Fecha de la consulta"/>
							<span id="sfeccon"></span>
						</div>

					</div>

					<div class="row">

						<div class="col">
							<label for="pesocon">Peso del paciente en la consulta</label>
							<input class="form-control" type="text" id="pesocon" name="pesocon" 
							pattern="[0-9]{2}[A-Za-z]{2}{2,4}" 
							required
							maxlength="4" 
							minlength="2" 
							title="Introducir un peso valido Ej. 40kg"/>
							<span id="spesocon"></span>
						</div>
						
						<div class="col">
							<label for="estcon">Estatura del paciente en la consulta</label>
							<input class="form-control" type="text" id="estcon" name="estcon"  
							pattern="[0-9]{3}[A-Za-z]{2}{3,5}" 
							required
							maxlength="5" 
							minlength="3" 
							title="Introducir una estatura valida Ej. 80cm"/>
							<span id="sestcon"></span>
						</div>

						<div class="col">
							<label for="fecingcon">Fecha de ingreso de la consulta</label>
							<input class="form-control" type="date" id="fecingcon" name="fecingcon"  
							required  
							title="Fecha de ingreso a la consulta"/>
							<span id="sfecingcon"></span>
						</div>

						<div class="col">
							<label for="nhmedico">Historial Médico</label>
							<input class="form-control" type="text" id="nhmedico" name="nhmedico" 
							pattern="[0-9]{5,7}"
							required 
							maxlength="7" 
							minlength="5" 
							title="Solo numeros entre 5 y 7"/>
							<span id="snhmedico"></span>
						</div>
					</div>

					<div class="row">

						<div class="col">
							<label for="hordorm">Horas que duerme el paciente</label>
							<input class="form-control" type="text" id="fhordorm" name="hordorm" 
							pattern="[0-9]{2}[A-Za-z]{3}" 
							required
							maxlength="5" 
							minlength="3" 
							title="Horas que duerme el paciente Ej. 2hr, 30min"/>
							<span id="shordorm"></span>
						</div>

						<div class="col">
							<label for="estnacimiento">Estatura de nacimiento</label>
							<input class="form-control" type="text" id="Estnacimiento" name="estnacimiento"  
							pattern="[0-9]{3}[A-Za-z]{2}{3,5}" 
							required
							maxlength="5" 
							minlength="3" 
							title="Introducir una estatura valida Ej. 40cm"/>
							<span id="sestnacimiento"></span>
						</div>
					</div>

					<div class="row">

						<div class="col">
							<label for="examenfis">Examen físico del paciente</label>
							<input class="form-control" type="text" id="examenfis" name="examenfis" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{7,20}" 
							required
							maxlength="20" 
							minlength="7" 
							title="Introducir el examen realizado al paciente"/>
							<span id="sexamenfis"></span>
						</div>

						<div class="col">
							<label for="comppac">Complicaciones del paciente</label>
							<input class="form-control" type="text" id="comppac" name="comppac" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{12,50}" 
							required
							maxlength="50" 
							minlength="12" 
							title="Introducir las complicaciones presentadas por el paciente"/>
							<span id="scomppac"></span>
						</div>

						<div class="col">
							<label for="alimpac">Frecuencia alimentaria del paciente</label>
							<input class="form-control" type="text" id="alimpac" name="alimpac" 
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{12,20}" 
							required
							maxlength="20" 
							minlength="12" 
							title="Introducir la frecuencia en la que alimenta al niño"/>
							<span id="alimpac"></span>
						</div>	
					</div>

					<div class="row">
						<div class="col">
							<hr/>
						</div>
					</div>
			

				<div class="card-footer text-muted"> <!-- inicio de los botones -->
					<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
			</div><!-- fin del container que engloba todo -->
			</form>	

		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->

</body>

</html>