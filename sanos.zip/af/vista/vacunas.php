<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->	
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>

    <div id="contenidomed">
		<div class="card card-container">
			<div class="card-header">   	
				<div class="container text-center h2 text-black-50">
					Registro de vacunas
				</div>
			</div>

			    <div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
			    <form method="post" action="" id="f">
				<!--Caja de entrada invisible para indicar al servidor que boton fue pulsado-->
				<input type="text" name="accion" id="accion" style="display:none"/>		

					<div class="row">
						<div class="col">
							<label for="codvacuna">Codigo de la vacuna</label>
							<input class="form-control" type="text" id="codvacuna" name="codvacuna"/>
							<span id="scodvacuna"></span>
						</div>

					    <div class="col">
							<label for="vacunas">Nombre de las vacunas</label>
							<input class="form-control" type="text" id="vacunas" name="vacunas"/>
							<span id="svacunas"></span>
					    </div>
				    
				    	<div class="col">
							<label for="disponibilidad">Disponibilidad</label>
							<select class="form-control" name="disponibilidad" id="disponibilidad" />
							<option selected>Disponible</option>
							<option>No Disponible</option>
							<span id="sdisponibilidad"></span>
						    </select>
					    </div>
					</div>

				    <div class="row">
				    	<div class="col">
				    		<hr/>
				    	</div>
				    </div>

				<div class="card-footer text-muted"> <!-- inicio de los botones -->
						<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
			                <button type="button" class="btn btn-primary" id="consultar" 
			                data-toggle="modal" data-target="#modal1" name="consultar">CONSULTAR</button>
		                </div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
			</div><!-- fin del container que engloba todo -->
		</form>

		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->


<!-- seccion del modal -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modal1">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de vacunas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		  <th>Codigo Vacuna</th>
		  <th>Nombre de la Vacuna</th>
		  <th>Disponibilidad</th>
		  </tr>
		</thead>
		<tbody>
		  <?php
			if(!empty($consulta)){
				echo $consulta;
			}
		  ?>
		</tbody>
		</table>
    </div>
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->

<script type="text/javascript" src="js/vacunas.js"></script>

</body>
</html>