<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->	
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>
	

	<div id="contenidomed">
		<div class="card card-container">
			<div class="card-header">
				<div class="container text-center h2 text-black-50">
					Vacunas del paciente
				</div>
			</div>
		</div>
			<div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
            <form method="post" action="" id="f">
            <input type="text" name="accion" id="accion" style="display:none"/>

		
	<div class="row">
		<div class="col">
			<hr/>
		</div>
	</div>
					<div class="row">
						<div class="col">
							<label for="cedulacliente">Cedula del paciente</label>
		          <input class="form-control" type="text" id="cedulacliente" name="cedulacliente" placeholder="cedula del paciente"/>
		          <input class="form-control" type="text" id="idcliente" name="idcliente" style="display:none"/>
		        </div>

						<div class="col">
							<label for="fecvacuna">Fecha de vacuna</label>
							<input class="form-control" type="date" id="fecvacuna" name="fecvacuna"
							value="<?php 
						    $f = date('Y-m-d');
						    $f1 = strtotime ('-12 year' , strtotime($f)); 
					        $f1 = date ('Y-m-d',$f1);
					        echo $f1; ?>"
		                    />
							<span id="sfecvacuna"></span>
						</div>
	        </div>


	<!-- FILA DE DATOS DEL CLIENTE -->
	<div class="row">
		<div class="col" id="datosdelcliente">  
		</div>
	</div>
	<!-- FIN DE FILA DATOS DEL CLIENTE -->

				<div class="row">
					<div class="col">
						<hr/>
					</div>
				</div>


          <div class="row">
					  <div class="col-8 input-group">
		          <input class="form-control" type="text" id="cedularepresentante" name="cedularepresentante" placeholder="Ingrese el codigo de la vacuna" />
		          <input class="form-control" type="text" id="idrepresentante" name="idrepresentante" style="display:none"/>
		          <button type="button" class="btn btn-primary" id="modalderepresentantes" name="modalderepresentantes">Lista de vacunas</button>
		        </div>

		        <div class="col-4">
							<select class="form-control" name="dosisvacuna" id="dosisvacuna"/>
							<option selected>Seleccione una Dosis</option>
							<option>Primera</option>
							<option>Segunda</option>
							<option>Tercera</option>
							<span id="sdosisvacuna"></span>
						  </select>
					  </div>
				  </div>

				<!-- FILA DE DATOS DEL representante -->
	      <div class="row">
		      <div class="col-md-12" id="datosdelrepresentante">
		      </div>
	      </div>
	      <!-- FIN DE FILA DATOS DEL representante -->

  <div class="row">
		<div class="col">
		<hr/>
		</div>
	</div>
	         
	
	
			<div class="card-footer text-muted"> <!-- inicio de los botones -->
					<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
			        <button type="button" class="btn btn-primary" id="consultar" 
			        data-toggle="modal" data-target="#modal1" name="consultar">CONSULTAR</button>
		        </div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
			</div> <!-- fin de los botones -->
		</div><!-- fin del container que engloba todo -->
	</form>
	
	</div> <!-- fin de container card -->
</div> <!-- fin del contenidomed -->

<!-- seccion del modal clientes -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modalclientes">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de clientes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		    <th style="display:none">Id</th>
			<th>Cedula</th>
			<th>Nombre</th>
			<th>Telefono</th>
			<th>Direccion</th>
		  </tr>
		</thead>
		<tbody id="listadodeclientes">
		  <?php
			if(!empty($consultaclientes)){
				echo $consultaclientes;
			}
		  ?>
		</tbody>
		</table>
    </div>
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->

<!-- seccion del modal -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modal1">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de vacunas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		  <th>Fecha</th>
		  <th>Dosis</th>
		  <th>Cedula</th>
		  </tr>
		</thead>
		<tbody>
		  <?php
			if(!empty($consulta)){
				echo $consulta;
			}
		  ?>
		</tbody>
		</table>
    </div>
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->

<!-- seccion del modal representantes -->
<div class="modal fade" tabindex="-1" role="dialog"  id="modalrepresentantes">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-header text-light bg-info">
        <h5 class="modal-title">Listado de Vacunas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-content">
		<table class="table table-striped table-hover">
		<thead>
		  <tr>
		    <th style="display:none">Id</th>
			  <th>Codigo Vacuna</th>
		    <th>Nombre de la Vacuna</th>
		    <th>Disponibilidad</th>
		  </tr>
		</thead>
		<tbody id="listadoderepresentantes">
		  <?php
			if(!empty($consultarepresentantes)){
				echo $consultarepresentantes;
			}
		  ?>
		</tbody>
		</table>
    </div>
	<div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
    </div>
  </div>
</div>
<!--fin de seccion modal-->


<script type="text/javascript" src="js/vacunaspacientes.js"></script>

</body>
</html>