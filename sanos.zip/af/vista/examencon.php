<html>
<?php require_once("comunes/encabezado.php"); 
?>
<body>
<!--Div oculta para colocar el mensaje a mostrar-->
<div id="mensajes" style="display:none">
<?php
	if(!empty($mensaje)){
		echo $mensaje;
	}
?>	
</div>
<!--Llamada a archivo modal.php, dentro de el hay una sección modal-->
<?php require_once("comunes/modal.php"); ?>
<?php require_once("comunes/slidebar.php"); ?>

	<div id="contenidomed">
		<div class="card card-container">
            <div class="card-header">   	
				<div class="container text-center h2 text-black-50">
					Examenes recetados durante la consulta
				</div>
			</div>
        <div class="container"> <!-- todo el contenido ira dentro de esta etiqueta-->
    <form method="post" action="" id="f">
    <input type="text" name="accion" id="accion" style="display:none"/>

	<div class="row">
		<div class="col">
		<hr/>
		</div>
	</div>	
					<div class="row">
						<div class="col">
							<label for="nexamen">Numero de Examen</label>
							<input class="form-control" type="text" id="nexamen" name="nexamen" 
							pattern="[0-9]{5,7}"
							required 
							maxlength="7" 
							minlength="5" 
							title="Solo numeros entre 5 y 7"/>
							<span id="snexamen"></span>
						</div>

						<div class="col">
							<label for="nconsulta">Numero de control de consulta</label>
							<input class="form-control" type="text" id="nconsulta" name="nconsulta" 
							pattern="[0-9]{5,7}"
							required 
							maxlength="7" 
							minlength="5" 
							title="Solo numeros entre 5 y 7"/>
							<span id="snconsulta"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<label for="fecexamen">Fecha del examen</label>
							<input class="form-control" type="date" id="fecexamen" name="fecexamen"  
							required  
							title="Fecha del examen"/>
							<span id="sfecexamen"></span>
						</div>

						<div class="col">
							<label for="tipoexamen">Tipo de examen a realizar</label>
							<input class="form-control" type="text" id="tipoexamen" name="tipoexamen"  
							pattern="[A-Za-z\b\s\u00f1\u00d1\u00E0-\u00FC]{25,50}" 
							required 
							maxlength="50" 
							minlength="25" 
							title="Examen a realizar"/>
							<span id="stipoexamen"></span>
						</div>
					</div>

					<div class="row">
						<div class="col">
							<hr/>
						</div>
					</div>
			

				<div class="card-footer text-muted"> <!-- inicio de los botones -->
						<div class="row">
						<div class="col">
							<button type="submit" class="btn btn-black-50" id="incluir" name="incluir"><img src="img/+.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="modificar" name="modificar"><img src="img/editar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
						<div class="col">	
							<button type="submit" class="btn btn-black-50" id="eliminar" name="eliminar"><img src="img/borrar.png" alt="" width="18" height="18" class="rounded-circle me-2"></button>
						</div>
					</div>
				</div> <!-- fin de los botones -->
			</div><!-- fin del container que engloba todo -->
			</form>
		</div> <!-- fin de container card -->
	</div> <!-- fin del contenidomed -->

</body>
</html>